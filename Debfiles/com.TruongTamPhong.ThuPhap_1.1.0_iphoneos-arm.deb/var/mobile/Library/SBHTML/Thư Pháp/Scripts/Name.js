function calendarDate ( )
{if (Lang == "vn"){
	var this_weekday_name_array= 








["Sinh Tử Hữu Mệnh Phú Quý Tại Thiên", 

"Nhất Ngôn Ký Xuất Tứ Mã Nan Truy", 

"Phúc Bất Trùng Lai Hoạ Vô Đơn Chí", 

"Hoa Rơi Hữu Ý Nước Chảy Vô Tình", 

"Giag Sơn Dễ Đổi Bản Tính Khó Dời", 

"Nhật Xuất Vạn Ngôn Tất Hữu Nhất Thươg", 

"Anh Hùng Nan Quá Mỹ Nhân Quan"];















}

  var this_date_timestamp = new Date()	  
  var this_weekday = this_date_timestamp.getDay()
document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday] //concat long date string
}
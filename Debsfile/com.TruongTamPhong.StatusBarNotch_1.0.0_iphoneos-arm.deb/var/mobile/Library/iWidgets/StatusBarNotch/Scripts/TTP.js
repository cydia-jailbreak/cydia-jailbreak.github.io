/* */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":"2.2px","border-color":"rgb(255,255,255)","border-width":"1px","position":"absolute","border-radius":"4.8px","width":"314px","box-shadow":"rgb(255,255,255) 0px 0px 10px","height":"13.5px","background-color":"rgba(0, 0, 0, 0)","z-index":"1","border-style":"solid","top":15,"-webkit-transform":"rotate(0deg)"}},"iconName":"simply"}



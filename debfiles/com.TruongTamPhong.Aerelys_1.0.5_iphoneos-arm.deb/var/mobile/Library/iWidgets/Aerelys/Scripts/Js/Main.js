window.addEventListener("load", function() {}, false);
function init(){
if(da === 1){
updateClock();
if(ti === 0){
setInterval("updateClock();", 120000);}
else{
document.getElementById("day").style.fontFamily = 'TamPhong';
document.getElementById("day").style.fontSize = '20px'
document.getElementById("date").style.fontFamily = 'TruongTamPhong';
document.getElementById("date").style.fontSize = '12px'
document.getElementById("date").style.textTransform = 'uppercase';
setInterval("updateClock();", 1000);}}
checkSettings();}
function checkSettings(){
document.documentElement.style.setProperty('--br', br + 'px');
document.documentElement.style.setProperty('--bl', bl + 'px');
document.documentElement.style.setProperty('--primary', C1);
document.documentElement.style.setProperty('--secondary', C2);
document.documentElement.style.setProperty('--aBg', aBg);
if(da === 0){
document.getElementById('dateCont').style.display = 'none';}
document.documentElement.style.setProperty('--dX', dX + 'px');
document.documentElement.style.setProperty('--dY', dY + 'px');
if(se === 0){
document.getElementById('searchCont').style.display = 'none';}
document.documentElement.style.setProperty('--sW', sW + '%');
document.documentElement.style.setProperty('--sX', sX + '%');
document.documentElement.style.setProperty('--sY', sY + 'px');
document.documentElement.style.setProperty('--sBg', sBg);
document.getElementById("in").placeholder = ph;
if(we === 0){
document.getElementById('weaCont').style.display = 'none';}
document.documentElement.style.setProperty('--wW', wW + 'px');
document.documentElement.style.setProperty('--wX', wX + 'px');
document.documentElement.style.setProperty('--wY', wY + 'px');
if(mu === 0){
document.getElementById('musCont').style.display = 'none';}
document.documentElement.style.setProperty('--mW', mW + 'px');
document.documentElement.style.setProperty('--mY', mY + 'px');
if(ba === 0){
document.getElementById('battCont').style.display = 'none';}
document.documentElement.style.setProperty('--bW', bW + 'px');
document.documentElement.style.setProperty('--bX', bX + 'px');
document.documentElement.style.setProperty('--bY', bY + 'px');
if(ac === 0){
document.getElementById('appCont').style.display = 'none';}
document.documentElement.style.setProperty('--aW', aW + '%');
document.documentElement.style.setProperty('--aH', aH + 'px');
document.documentElement.style.setProperty('--aX', aX + '%');
document.documentElement.style.setProperty('--aY', aY + 'px');
if(ac2 === 0){
document.getElementById('appCont2').style.display = 'none';}
document.documentElement.style.setProperty('--abW', abW + '%');
document.documentElement.style.setProperty('--abH', abH + 'px');
document.documentElement.style.setProperty('--abX', abX + '%');
document.documentElement.style.setProperty('--abY', abY + 'px');}
function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes();
var currentMinutes1 = currentTime.getMinutes();
var currentMinutesunit = currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentYear = currentTime.getFullYear();
if(ti === 1){
if(Time24 === 1){Clock = "24h";}
else{Clock = "12h";}
if (Clock === "24h"){currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;}
if (Clock === "12h"){currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
currentHours = ( currentHours == 0 ) ? 12 : currentHours;
currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;}
document.getElementById("day").innerHTML = currentHours + ':' + currentMinutes1 + ' | ';
document.getElementById("date").innerHTML = shortdays[currentTime.getDay()] + '/' + currentDate + ' ' + shortmonths[currentTime.getMonth()];}
else{
document.getElementById("day").innerHTML = days[currentTime.getDay()] + " | "
document.getElementById("date").innerHTML = currentDate + " " + shortmonths[currentTime.getMonth()];}}
var input = document.getElementById("in");
input.addEventListener("keyup", function(event) {
if (event.keyCode === 13) {event.preventDefault();
Search();}});
function Search(){
var input = document.getElementById("in").value;
if(input.trim() !== ''){
window.location = 'xeninfo:openurl:google.com.vn/search?q=' + input;
document.getElementById("in").value = "";}}
function openMu(){
if(document.getElementById("musCont").classList.contains('closed')){
document.getElementById("musCont").classList.remove('closed');
document.getElementById("plyBtn").classList.add('open');
document.getElementById("musicArt").classList.remove('open');
document.getElementById("musicArt").classList.add('closed');
return;}
else{
document.getElementById("musCont").classList.add('closed');
document.getElementById("plyBtn").classList.remove('open');
document.getElementById("musicArt").classList.add('open');
document.getElementById("musicArt").classList.remove('closed');
return;}}
function checkMusic(){
if (isplaying === 1) {
document.getElementById('playPause').classList.remove("zeek-buttonplay");
document.getElementById('playPause').classList.add("zeek-buttonpause");}
else{
document.getElementById('playPause').classList.remove("zeek-buttonpause");
document.getElementById('playPause').classList.add("zeek-buttonplay");}
if(title === "(null)"){document.getElementById('title').innerHTML = 'Chưa phát';} else {document.getElementById('title').innerHTML = title;} 
if(artist === "(null)"){document.getElementById('artist').innerHTML = 'Không có nghệ sĩ';} else {document.getElementById('artist').innerHTML = artist;}
if(album === "(null)"){
document.getElementById('musicArt').src = 'Scripts/Js/Mus.js';}
else{
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();

if (xhr.status === "404") {
document.getElementById('musicArt').src = 'Scripts/Js/Mus.js';}
else{
document.getElementById('musicArt').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();}}}


function playPause() {
if ( document.getElementById('playPause').classList.contains("zeek-buttonplay")){ 
document.getElementById('playPause').classList.remove("zeek-buttonplay");
document.getElementById('playPause').classList.add("zeek-buttonpause");}
else{ 
document.getElementById('playPause').classList.remove("zeek-buttonpause");
document.getElementById('playPause').classList.add("zeek-buttonplay");}
window.location = 'xeninfo:playpause';}
function next() {
window.location = 'xeninfo:nexttrack';}
function prev() {
window.location = 'xeninfo:prevtrack';}
var checkSettings = function(){
}
checkSettings();
if(al === 0){
document.getElementById('AmLich').style.display = 'none';}
if(bat === 0){
document.getElementById('Battery').style.display = 'none';}
if(da === 0){
document.getElementById('XuThe').style.display = 'none';}
if(ti === 0){
document.getElementById('TinhYeu').style.display = 'none';}

document.documentElement.style.setProperty('--conW', conW + '%');
document.documentElement.style.setProperty('--blCl', '#' + blCl);

document.documentElement.style.setProperty('--alCl', '#' + C1);
document.documentElement.style.setProperty('--dnCl', '#' + C2);

document.documentElement.style.setProperty('--fontStyle', fontStyle);

document.documentElement.style.setProperty('--alTrans', alTrans);
document.documentElement.style.setProperty('--dnTrans', dnTrans);

document.documentElement.style.setProperty('--alAlign', alAlign);
document.documentElement.style.setProperty('--dnAlign', dnAlign);

document.documentElement.style.setProperty('--alAlign', alAlign);
document.documentElement.style.setProperty('--dnAlign', dnAlign);

document.documentElement.style.setProperty('--alSize', alSize + 'px');
document.documentElement.style.setProperty('--dnSize', dnSize + 'px');

document.documentElement.style.setProperty('--alSh', alSh + 'px');
document.documentElement.style.setProperty('--dnSh', dnSh + 'px');

document.documentElement.style.setProperty('--alShCl', '#' + alShCl);
document.documentElement.style.setProperty('--batShCl', '#' + batShCl);
document.documentElement.style.setProperty('--dnShCl', '#' + dnShCl);
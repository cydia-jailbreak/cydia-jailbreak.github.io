function checkSettings(){

// General settings
document.documentElement.style.setProperty('--CityCl', config.CityCl);
document.documentElement.style.setProperty('--TextColor', config.TextColor);
document.documentElement.style.setProperty('--BgBl', config.BgBl + 'px');

/*---- Music ----*/
document.documentElement.style.setProperty('--AlbumBr', config.AlbumBr + 'px');
document.documentElement.style.setProperty('--AlbumSize', config.AlbumSize + 'px');

// Analog settings
document.documentElement.style.setProperty('--primary', config.C1);
document.documentElement.style.setProperty('--secondary', config.C2);
document.documentElement.style.setProperty('--third', config.C3);
document.documentElement.style.setProperty('--cBg', config.cBg);
document.documentElement.style.setProperty('--lBg', config.lBg);
document.documentElement.style.setProperty('--nC', config.nC);
document.documentElement.style.setProperty('--sc', config.sc);

if(!config.ct){
document.getElementById("Cir").style.display = 'none';
} else {
document.getElementById("Cir").innerHTML = config.ctt;
}

switch (config.bg) {
case 1:
break;
case 2:
document.getElementById("Container").style.background = 'none';
document.getElementById("Container").classList.add('AddBlur');
break;
case 3:
document.getElementById("Container").classList.add('AddBlur');
break;
case 4:
document.getElementById("Container").style.background = 'none';
break;}}

document.getElementById("Shadow").src="Scripts/Js/Sh.js";
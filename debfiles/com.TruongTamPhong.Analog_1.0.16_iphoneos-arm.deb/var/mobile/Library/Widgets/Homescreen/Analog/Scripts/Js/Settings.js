function checkSettings(){

// General settings
document.documentElement.style.setProperty('--Trans', config.Trans + 'px');
document.documentElement.style.setProperty('--BgBl', config.BgBl + 'px');
document.getElementById('Wall').style.backgroundImage = 'url' + '(' + config.Link + ')';
document.getElementById("Shadow").src="Scripts/Js/Sh.js";

/*---- Border radius----*/
document.documentElement.style.setProperty('--BgBr', config.BgBr + 'px');
document.documentElement.style.setProperty('--DayBr', config.DayBr + 'px');
document.documentElement.style.setProperty('--ContrBr', config.ContrBr + 'px');

/*---- Color ----*/
document.documentElement.style.setProperty('--CityCl', config.CityCl);
document.documentElement.style.setProperty('--BoxCl', config.BoxCl);
document.documentElement.style.setProperty('--TextColor', config.TextColor);

/*---- Music ----*/
document.documentElement.style.setProperty('--AlbumBr', config.AlbumBr + 'px');
document.documentElement.style.setProperty('--AlbumSize', config.AlbumSize + 'px');

/*---- On off ----*/
if(!config.WeaCont){
document.getElementById("City").style.display = 'none';
document.getElementById("WeatherInfo").style.display = 'none';
document.getElementById("DayCont").style.display = 'none';
}
if(!config.AnalogCont){
document.getElementById("AnalogCont").style.display = 'none';
}
if(!config.MuCont){
document.getElementById("MuCont").style.display = 'none';
}

/*---- Analog settings ----*/
document.documentElement.style.setProperty('--primary', config.C1);
document.documentElement.style.setProperty('--secondary', config.C2);
document.documentElement.style.setProperty('--third', config.C3);
document.documentElement.style.setProperty('--cBg', config.cBg);
document.documentElement.style.setProperty('--lBg', config.lBg);
document.documentElement.style.setProperty('--nC', config.nC);
document.documentElement.style.setProperty('--sc', config.sc);
if(!config.ct){
document.getElementById("Cir").style.display = 'none';
} else {
document.getElementById("Cir").innerHTML = config.ctt;
}
switch (config.bg) {
case 1:
break;
case 2:
document.getElementById("AnalogCont").style.background = 'none';
document.getElementById("AnalogCont").classList.add('AddBlur');
break;
case 3:
document.getElementById("AnalogCont").classList.add('AddBlur');
break;
case 4:
document.getElementById("AnalogCont").style.background = 'none';
break;}
}
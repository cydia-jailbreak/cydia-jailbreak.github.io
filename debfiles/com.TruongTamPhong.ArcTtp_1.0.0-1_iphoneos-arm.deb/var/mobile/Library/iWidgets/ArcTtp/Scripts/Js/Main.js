
window.addEventListener("load", function() { 
}, false);
function init(){
	updateClock();
	setInterval("updateClock();", 5000);
	checkSettings();}
function setDark(){
	if(sh === 'ou'){
document.getElementById('appsCont').classList.remove('morph');
document.getElementById('appsCont2').classList.remove('morph');
document.getElementById('appsCont3').classList.remove('morph');
document.getElementById('_genCont').classList.remove('morph');
document.getElementById('bl1').classList.remove('morph');
document.getElementById('_musCont').classList.remove('morph');
document.getElementById('prev').classList.remove('morph');
document.getElementById('playPause').classList.remove('morph');
document.getElementById('next').classList.remove('morph');
document.getElementById('appsCont').classList.remove('morph-light-out');
document.getElementById('appsCont2').classList.remove('morph-light-out');
document.getElementById('appsCont3').classList.remove('morph-light-out');
document.getElementById('_genCont').classList.remove('morph-light-out');
document.getElementById('bl1').classList.remove('morph-light-out');
document.getElementById('_musCont').classList.remove('morph-light-out');
document.getElementById('prev').classList.remove('morph-light-out');
document.getElementById('playPause').classList.remove('morph-light-out');
document.getElementById('next').classList.remove('morph-light-out');
document.getElementById('appsCont').classList.add('morph-dark-out');
document.getElementById('appsCont2').classList.add('morph-dark-out');
document.getElementById('appsCont3').classList.add('morph-dark-out');
document.getElementById('_genCont').classList.add('morph-dark-out');
document.getElementById('bl1').classList.add('morph-dark-out');
document.getElementById('_musCont').classList.add('morph-dark-out');
document.getElementById('prev').classList.add('morph-dark-out');
document.getElementById('playPause').classList.add('morph-dark-out');
document.getElementById('next').classList.add('morph-dark-out');
	}
}
function setLight(){
	if(sh === 'ou'){
document.getElementById('appsCont').classList.remove('morph');
document.getElementById('appsCont2').classList.remove('morph');
document.getElementById('appsCont3').classList.remove('morph');
document.getElementById('_genCont').classList.remove('morph');
document.getElementById('bl1').classList.remove('morph');
document.getElementById('_musCont').classList.remove('morph');
document.getElementById('prev').classList.remove('morph');
document.getElementById('playPause').classList.remove('morph');
document.getElementById('next').classList.remove('morph');
document.getElementById('appsCont').classList.remove('morph-dark-out');
document.getElementById('appsCont2').classList.remove('morph-dark-out');
document.getElementById('appsCont3').classList.remove('morph-dark-out');
document.getElementById('_genCont').classList.remove('morph-dark-out');
document.getElementById('bl1').classList.remove('morph-dark-out');
document.getElementById('_musCont').classList.remove('morph-dark-out');
document.getElementById('prev').classList.remove('morph-dark-out');
document.getElementById('playPause').classList.remove('morph-dark-out');
document.getElementById('next').classList.remove('morph-dark-out');
document.getElementById('appsCont').classList.add('morph-light-out');
document.getElementById('appsCont2').classList.add('morph-light-out');
document.getElementById('appsCont3').classList.add('morph-light-out');
document.getElementById('_genCont').classList.add('morph-light-out');
document.getElementById('bl1').classList.add('morph-light-out');
document.getElementById('_musCont').classList.add('morph-light-out');
document.getElementById('prev').classList.add('morph-light-out');
document.getElementById('playPause').classList.add('morph-light-out');
document.getElementById('next').classList.add('morph-light-out');}
}
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	var Time24 = 1;
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	document.getElementById("Đồng_Hồ").innerHTML = currentHours + "." + currentMinutes1;
	document.getElementById("Tháng").innerHTML = shortmonths[currentTime.getMonth()];
	document.getElementById("Ngày").innerHTML = currentDate;
	document.getElementById("Thứ").innerHTML = shortdays[currentTime.getDay()];
	
}
function openApp(){
	window.location = 'xeninfo:openapp:' + mb;
}
var mus = document.getElementById('_musCont');
var gen = document.getElementById('_genCont');
function openWid(){
	if(one === 1){
		if(mus.classList.contains('closed')){
			mus.classList.remove('closed');
			mus.classList.add('open');
			gen.classList.remove('open');
			gen.classList.add('closed');
			mus.style.zIndex = 0;
			gen.style.zIndex = -1;
			mus.style.display = 'block';
			TweenMax.to(mus, 0.5, {alpha:1});
			TweenMax.to(gen, 0.5, {alpha:0, onComplete:function(){
			gen.style.display = 'none';	
			}});
document.getElementById('mArt').classList.remove('closed');
document.getElementById('infoCont').classList.remove('closed');
document.getElementById('controls').classList.remove('closed');
document.getElementById('_date').classList.add('closed');
document.getElementById('weaCont').classList.add('closed');
document.getElementById('_batCont').classList.add('closed');
			return;
		}else{
			mus.classList.add('closed');
			mus.classList.remove('open');
			gen.classList.remove('closed');
			gen.classList.add('open');
			mus.style.zIndex = -1;
			gen.style.zIndex = 0;
			gen.style.display = 'block';
			TweenMax.to(gen, 0.5, {alpha:1});
			TweenMax.to(mus, 0.5, {alpha:0, onComplete:function(){
			mus.style.display = 'none';	
			}});
document.getElementById('_date').classList.remove('closed');
document.getElementById('weaCont').classList.remove('closed');
document.getElementById('_batCont').classList.remove('closed');
document.getElementById('mArt').classList.add('closed');
document.getElementById('infoCont').classList.add('closed');
document.getElementById('controls').classList.add('closed');
return;}}
}
var translationData={};const WriteMod={ByWord:0,ByLetter:1,ByLetterFixed:2,Text:3},TextTransform={RemoveAccent:0,UpperCase:1,LowerCase:2};var DynamicData=function(e){if(e.Bottom||(e.Bottom=0),e.RightLeft||(e. RightLeft=0),e.RightLeft/=100,e.WriteMod||(e.WriteMod=WriteMod.ByWord),e.TextTransform||(e.TextTransform=[]),e.WriteMod==WriteMod.Text?e.Tag=["Br"]:e.Tag||(e.Tag=["Br","Size","Color"]),e.UseIconWeather||(e.UseIconWeather=0),e.TimeRefresh||(e.TimeRefresh="auto"),!e.CityCode||-1==e.CityCode){var t=VaExist("DEFAULT_WEATHER_ID",-1);e.CityCode=-1!=t?DEFAULT_WEATHER_ID:-1}e.DefaultFontSize||(e.DefaultFontSize=""),e.Callback=e.Callback||(e=>e),e.UseIconWeather&&AddStyleSheet("weather",!0);var n,r={},a={},o={Get:function(t){var n=t?new Date(t):new Date;return{hour:function(){var t=e.Twentyfour?n.getHours():(n.getHours()+11)%12+1;return""+(e.PadZero?o.Add0(t):t)},minute:function(){return o.Add0(n.getMinutes())},am:function(){return e.Twentyfour?"":n.getHours()>11?"PM":"AM"},date:function(){return n.getDate()+(e.Nth?this.nth():"")},month:function(){return n.getMonth()+1},year:function(){return n.getFullYear()},syear:function(){return String(this.year()).substr(2,2)},daytext:function(){return i("weekday",n.getDay())},sdaytext:function(){return i("sday",n.getDay())},monthtext:function(){return i("month",n.getMonth())},smonthtext:function(){return i("smonth",n.getMonth())},nth:function(){switch(Number(n.getDate())){case 1:return"st";case 2:return"nd";case 3:return"rd";default:return"th"}}}},Add0:function(e){return e<10?"0"+e:e},GetTime:function(){return 1*(new Date).getTime()}},i=(n=window.navigator.language.length>=2?window.navigator.language.split("-")[0]:"en",!translationData[n]&&(n="en"),e.Lang="default"==e.Lang?n:null!=translationData[e.Lang]?e.Lang:n,translationData=translationData[e.Lang],function(e,t){return translationData[e][t]}),u={hour:function(){return a.hour()},am:function(){return a.am().toLowerCase()},Am:function(){return"AM"==a.am()?"Am":"Pm"},AM:function(){return a.am()},minute:function(){return a.minute()},date:function(){return a.date()},month:function(){return a.month()},year:function(){return a.year()},syear:function(){return a.syear()},dayname:function(){return a.daytext()},sdayname:function(){return a.sdaytext()},monthname:function(){return a.monthtext()},smonthname:function(){return a.smonthtext()},icon:function(){return r.Icon?'<i class="owf '+r.Icon+'"></i>':void 0},temp:function(){return r.Temperature},condition:function(){return r.Condition},city:function(){return r.City},wind:function(){return r.Wind},humidity:function(){return r.Humidity},visibility:function(){return r.Visibility},sunset:function(){return r.SunSet},sunrise:function(){return r.SunRise},lon:function(){return r.Lon},lat:function(){return r.Lat},pressure:function(){return r.Pressure},clouds:function(){return r.Clouds},rain:function(){return r.Rain},snow:function(){return r.Snow}},s=function(){a=o.Get(),""!=VaExist("API_KEYS","")&&e.CityCode&&-1!=e.CityCode&&function(t){var n=e.CityCode+e.Units+e.Lang,r=e.Namespace+"_weather_";window._WeatherCallback=function(a){let i=Storage(0,r,1);if((!i||i.Time<o.GetTime()||i.ID!=n)&&Storage(1,r,{Data:a,ID:n,Time:o.GetTime()+156e4}),a&&200==a.cod){var u=o.Get(1e3*GetInterne("sys/sunrise",a)),s=o.Get(1e3*GetInterne("sys/sunset",a)),l=GetInterne("wind/speed",a);t({City:a.name,Lon:GetInterne("coord/lon",a),Lat:GetInterne("coord/lat",a),Condition:FirstLetterUpperCase(GetInterne("weather/0/description",a)),Temperature:Math.round(1*GetInterne("main/temp",a))+(e.Units?"°C":"°F"),Pressure:GetInterne("main/pressure",a)+" hPa",Humidity:GetInterne("main/humidity",a)+"%",Wind:e.Units?Math.round(3.6*l)+" km/h":l+" mi/h",SunRise:u.hour()+":"+u.minute()+" "+u.am(),SunSet:s.hour()+":"+s.minute()+" "+s.am(),Icon:"owf-"+GetInterne("weather/0/id",a),Clouds:(GetInterne("clouds/all",a)||"0")+"%",Rain:(GetInterne("rain/3h",a)||"0")+"mm",Snow:(GetInterne("snow/3h",a)||"0")+"mm"})}};var a=new Div("_weather-script_");let i=Storage(0,r,1);!i||i.Time<o.GetTime()||i.ID!=n?(a.Clear(),a.AppendScript("http://api.openweathermap.org/data/2.5/weather?id="+e.CityCode+"&APPID="+API_KEYS+"&lang="+e.Lang+"&callback=_WeatherCallback&lang="+e.Lang+"&units="+(e.Units?"metric":"imperial"))):_WeatherCallback(i.Data)}(function(e){r=e})},l={AnalyseFormat:function(t){t=t.replace(/(\[br\]+) ?/g,"[br] ");for(var n,r=/\[([a-z0-9\\.-\\,\\#]+)\]/,a=[],o=[],i=[],u=[],s=-1!=e.Tag.indexOf("Br"),l=-1!=e.Tag.indexOf("Size"),c=-1!=e.Tag.indexOf("Color");n=r.exec(t);){l&&n[1].match(/^s[0-9]+(\.[0-9]+)?$/)&&a.push([n.index-1,1*n[1].replace("s","")]),s&&"br"==n[1]&&(-1!=o.indexOf(n.index)?i[o.indexOf(n.index)][1]++:(o.push(n.index),i.push([n.index,1])));let e=0,d=0,m=0;c&&"br"!=n[1]&&((e=n[1].match(/^[a-zA-Z]+$/))||(d=n[1].match(/^[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}$/))||n[1].match(/^[0-9]{1,3}\,[0-9]{1,3}\,[0-9]{1,3}(\,[0-1](\.[0-9]{2})?)$/)||(m=n[1].match(/^\#[0-9a-zA-Z]{1,6}$/)))&&u.push([n.index-1,e||m?n[1]:d?"rgb("+n[1]+")":"rgba("+n[1]+")"]),t=t.replace(r,"")}return{Str:t,Data:{Size:a,Br:i,Color:u}}},AnalyseDynamicStructure:function(e,t){if(!e.length)return null;var n=0;return e=e.replace(/\{(.*?)\}/gi,function(e,t){let r="sec"==t?"{sec}":null!=u[t]?u[t]():"";return null!=r&&null!=r&&""!=r||(r="",n=1),r}),t&&n?null:e},ApplyData:function(e){Each(e,function(e,t){if(t.Words.length){t.WordsData=[];for(var n="!"==t.Words[0].Str[0],r=0,a=0;a<t.Words.length;a++)if(t.Words[a].VaDynamic){var o=l.AnalyseDynamicStructure(t.Words[a].Str,n);if((""==o||null==o)&&(r=1,n))break;t.WordsData.push(o)}else t.WordsData.push(t.Words[a].Str);n&&t.WordsData.length&&(t.WordsData[0]=t.WordsData[0].replace(/^!/,"")),n&&r&&(t.WordsData=[])}})},ApplySecond:function(e){var t=o.Add0((new Date).getSeconds());Each(e.IndexSecond,function(n,r){e.WordsData[r]&&(e.WordsData[r]=e.Words[r].Str.replace(/\{sec\}/gi,t),e.Words[r].VaDynamic&&(e.WordsData[r]=l.AnalyseDynamicStructure(e.WordsData[r])))})},PreBuild:function(t,n){var r=t.split(" "),a=[],o=0,i=[];return Each(r,function(t,u){var s=[];Each(r[t],function(e,t){s.length&&(s[s.length-1].Size!=n[o].Size||s[s.length-1].Color!=n[o].Color)||!s.length?s.push({Size:n[o].Size,Color:n[o].Color,Str:t,Br:0}):s[s.length-1].Str+=t,o++}),s.length?(n[o]&&(s[s.length-1].Br=n[o].Br),Each(s,function(t,n){n.VaDynamic=0,n.NoSpace=t+1<s.length,n.Str.match(/\{sec\}/gi)&&i.push(a.length),l.AnalyseDynamicStructure(n.Str)!=n.Str&&(n.VaDynamic=1),""==n.Size&&(n.Size=e.DefaultFontSize),a.push(n)})):a.push({Size:n[o].Size||e.DefaultFontSize,Str:"",Br:n[o].Br,VaDynamic:0,NoSpace:!1}),o+1<n.length&&o++}),{Words:a,IndexSecond:i,WordsData:[]}},WriteHtml:function(t,n,r){var a="<"+t+' class="'+e.ClassElement+'" ';return(n||r||e.Bottom)&&(a+='style="',n&&(a+="font-size:"+n+"px;",e.WriteMod==WriteMod.ByLetterFixed&&(a+="width:"+n*(1+e.RightLeft)+"px;")),r&&(a+="color:"+r+";"),e.Bottom&&(a+="margin-bottom:"+e.Bottom+"px;"),a+='" '),a+=">"},BuildString:null},c=-1!=e.TextTransform.indexOf(TextTransform.RemoveAccent),d=-1!=e.TextTransform.indexOf(TextTransform.UpperCase),m=-1!=e.TextTransform.indexOf(TextTransform.LowerCase);switch(l.ApplyTextTransform=function(t){return e.TextTransform.length&&(c&&(t=RemoveAccent(t)),d&&(t=t.toUpperCase()),m&&(t=t.toLowerCase())),t},e.WriteMod){case WriteMod.ByWord:l.BuildString=function(e){var t="";Each(e.WordsData,function(n,r){var a=e.Words[n];t+=l.WriteHtml("div",a.Size,a.Color)+l.ApplyTextTransform(e.WordsData[n]),0==a.Br&&!a.NoSpace&&n+1<e.Words.length&&(t+="&nbsp;"),t+="</div>";for(var o=0;o<a.Br;o++)t+="<br>"}),e.Container.innerHTML=t};break;case WriteMod.Text:l.BuildString=function(e){var t="";Each(e.WordsData,function(n,r){var a=e.Words[n];t+=l.ApplyTextTransform(e.WordsData[n]),0==a.Br&&!a.NoSpace&&n+1<e.Words.length&&(t+="&nbsp;");for(var o=0;o<a.Br;o++)t+="<br>"}),e.Container.innerHTML=t};break;case WriteMod.ByLetter:l.BuildString=function(e){var t="";Each(e.WordsData,function(n,r){var a=e.Words[n],o=l.WriteHtml("span",a.Size,a.Color);Each(r,function(e,n){t+=o+l.ApplyTextTransform(n)+"</span>"}),0==a.Br&&!a.NoSpace&&n+1<e.Words.length&&(t+=o+"&nbsp;</span>");for(var i=0;i<a.Br;i++)t+="<br>"}),e.Container.innerHTML=t};break;case WriteMod.ByLetterFixed:l.BuildString=function(t){var n=[],r=0,a=[],o=t.Container.clientWidth;Each(t.WordsData,function(i,u){var s="",c=0,d=0,m=i+1<t.Words.length,h=t.Words[i],f=l.WriteHtml("div",h.Size,h.Color);Each(u,function(t,n){s+=f+l.ApplyTextTransform(n)+"</div>";var r=h.Size*(1+e.RightLeft);c+=r,o<(d+=r)&&(d=0)});var S=m?h.Size*(1+e.RightLeft):0;if(o<r+c+S?(a.length>0&&n.splice(a[a.length-1],1),0!=n.length&&"<br>"!=n[n.length-1]&&n.push("<br>"),r=o<c?d:c):r+=c+S,""!=s&&n.push(s),m)if(h.Br>0){for(var p=0;p<h.Br;p++)n.push("<br>");r=0}else h.NoSpace||(a.push(n.length),n.push(f+"&nbsp;</div>"))}),t.Container.innerHTML=result}}!function(){s(),e.DeleteOption&&Each(e.DeleteOption,function(e,t){u[t]&&delete u[t]});var t=[];if(Each(e.Str,function(n,r){var a=[];Each(r,function(t,n){if(n.Element){var r=l.AnalyseFormat(n.Element),o=function(e){for(var t=0;t<r.Data.Size.length;t++){var n=r.Data.Size[t][0],a=null==r.Data.Size[t+1]?r.Str.length-1:r.Data.Size[t+1][0];if(n<=e&&a>=e)return r.Data.Size[t][1]}return""},i=function(e){for(var t=0;t<r.Data.Br.length;t++)if(r.Data.Br[t][0]==e)return r.Data.Br[t][1];return 0},u=function(e){for(var t=0;t<r.Data.Color.length;t++){var n=r.Data.Color[t][0],a=null==r.Data.Color[t+1]?r.Str.length-1:r.Data.Color[t+1][0];if(n<=e&&a>=e)return r.Data.Color[t][1]}return""},s=[];for(t=0;t<r.Str.length;t++)s.push({Color:u(t),Size:o(t),Br:i(t)});a.push(Object.assign(l.PreBuild(r.Str,s),{Container:"function"==typeof n.Container?n.Container:n.Container?n.Container:e.Container,HideWhenEmpty:n.HideWhenEmpty,UseCallback:"function"==typeof n.Container}))}}),a.length&&t.push(a)}),!(t.length<1)){var n=0,r=-1,a=0,i={},c=0,d=function(u){var s=0;0==n&&(s=c>=t.length,c=0),e.BeforeWrite&&e.BeforeWrite();var m=t[n],h=function(){u&&!s||++n>=t.length&&(r=-1,n=0),d()},f=function(){if(e.CallbackTime&&e.CallbackTime>0&&!a){var t=1;Each(i,(e,n)=>t&=n.Stop),t&&(a=1,setTimeout(function(){i={},a=0,h()},e.CallbackTime))}};Each(m,function(t,a){if(a.WordsData.length&&a.WordsData[0]||a.UseCallback){var c=o.GetTime()+""+Math.random();i[c]={LastUpdate:0,Stop:0};var d=JSON.stringify(a.Words),m=function(){return{IndexGroupStr:n,IndexStr:t,Element:{Container:a.UseCallback?null:a.Container,IndexSeconds:a.IndexSecond.slice(0),Words:JSON.parse(d),WordsData:a.WordsData.slice(0),Text:function(){var e="";return Each(a.WordsData,function(t,n){var r=a.Words[t];e+=l.ApplyTextTransform(a.WordsData[t]),0==r.Br&&!r.NoSpace&&t+1<a.Words.length&&(e+="&nbsp;")}),e},StringBuild:a.UseCallback?l.BuildString:null},Next:n!=r}},h=function(t){var n=function(){if(null!=i[c]){var r=Math.abs(o.GetTime()-i[c].LastUpdate)>=1e3;a.IndexSecond.length&&r&&l.ApplySecond(a);var d=e.Callback(m());a.UseCallback?a.Container(d.Element):l.BuildString(d.Element);var h=(new Date).getMilliseconds();null!=d.Stop&&d.Stop||-1==t?(u&&!s||!a.IndexSecond.length||(setTimeout(n,1e3-h),i[c].LastUpdate=o.GetTime()-h-15),i[c].Stop=1,f()):(setTimeout(n,t),r&&(i[c].LastUpdate=o.GetTime()-h-15))}};n()};if("auto"==e.TimeRefresh)if(a.IndexSecond.length)h(-1);else{var S=e.Callback(m());a.UseCallback?a.Container(S.Element):l.BuildString(S.Element),i[c].Stop=1,f()}else h(e.TimeRefresh);a.HideWhenEmpty&&!a.IsCallback&&(a.Container.style.display="")}else a.HideWhenEmpty&&!a.IsCallback&&(a.Container.style.display="none")}),r=n,0==Object.keys(i).length?(c++,e.WhenEmpty&&e.WhenEmpty(),c<t.length&&h()):e.WhenWrite&&e.WhenWrite()};Each(t,function(e,t){l.ApplyData(t)}),d(),OnMinuteChange(function(){s(),Each(t,function(e,t){l.ApplyData(t)}),d(1)})}}()},DynamicStr=function(e,t,n){this.Element=e,this.Container=t,this.HideWhenEmpty=n||0},DynamicCallback=function(e,t){this.Element=e,this.Stop=t};
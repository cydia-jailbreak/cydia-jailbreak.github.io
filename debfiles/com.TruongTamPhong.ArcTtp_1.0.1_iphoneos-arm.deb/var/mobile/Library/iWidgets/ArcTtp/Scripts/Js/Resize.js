if (iPhoneType == "auto") {
        if (screen.height == 667) { iPhoneType = "nhỏ mờ"; }
        else if (screen.height == 667) { iPhoneType = "nhỏ sáng"; }
        else if (screen.height == 667) { iPhoneType = "nhỏ tối"; }
        else if (screen.height == 667) { iPhoneType = "nhỏ trong"; }
	else if (screen.height == 736) { iPhoneType = "plus mờ"; }
	else if (screen.height == 736) { iPhoneType = "plus sáng"; }
	else if (screen.height == 736) { iPhoneType = "plus tối"; }
	else if (screen.height == 736) { iPhoneType = "plus trong"; }
	else if (screen.height == 812) { iPhoneType = "x mờ"; }
	else if (screen.height == 812) { iPhoneType = "x sáng"; }
	else if (screen.height == 812) { iPhoneType = "x tối"; }
	else if (screen.height == 812) { iPhoneType = "x trong"; }
	else if (screen.height == 896) { iPhoneType = "max mờ"; }
	else if (screen.height == 896) { iPhoneType = "max sáng"; }
	else if (screen.height == 896) { iPhoneType = "max tối"; }
	else if (screen.height == 896) { iPhoneType = "max trong"; }
	else { iPhoneType = "auto"; }
}

window.addEventListener("load", function() { 
	switch(iPhoneType) {
		case "nhỏ mờ":
			document.body.style.width='375px';
			document.body.style.height='667px';
		break;
		case "nhỏ sáng":
			document.body.style.width='375px';
			document.body.style.height='667px';
		break;
		case "nhỏ tối":
			document.body.style.width='375px';
			document.body.style.height='667px';
		break;
		case "nhỏ trong":
			document.body.style.width='375px';
			document.body.style.height='667px';
		break;
		case "plus mờ":
			document.body.style.width='414px';
			document.body.style.height='736px';
		break;
		case "plus sáng":
			document.body.style.width='414px';
			document.body.style.height='736px';
		break;
		case "plus tối":
			document.body.style.width='414px';
			document.body.style.height='736px';
		break;
		case "plus trong":
			document.body.style.width='414px';
			document.body.style.height='736px';
		break;
		case "x mờ":
			document.body.style.width='375px';
			document.body.style.height='812px';
		break;
		case "x sáng":
			document.body.style.width='375px';
			document.body.style.height='812px';
		break;
		case "x tối":
			document.body.style.width='375px';
			document.body.style.height='812px';
		break;
		case "x trong":
			document.body.style.width='375px';
			document.body.style.height='812px';
		break;
		case "max mờ":
			document.body.style.width='414px';
			document.body.style.height='896px';
		break;
		case "max sáng":
			document.body.style.width='414px';
			document.body.style.height='896px';
		break;
		case "max tối":
			document.body.style.width='414px';
			document.body.style.height='896px';
		break;
		case "max trong":
			document.body.style.width='414px';
			document.body.style.height='896px';
		break;
	}
}, false);

		$('head').removeAttr('Style');
                if (iPhoneType == 'nhỏ mờ') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MinBlur.css" type="text/css" >');
		}
		else if (iPhoneType == 'nhỏ sáng') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MinLight.css" type="text/css" >');
		}
		else if (iPhoneType == 'nhỏ tối') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MinDark.css" type="text/css" >');
		}
		else if (iPhoneType == 'nhỏ trong') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MinTransparent.css" type="text/css" >');
		}
		else if (iPhoneType == 'max mờ') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MaxBlur.css" type="text/css" >');
		}
		else if (iPhoneType == 'max sáng') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MaxLight.css" type="text/css" >');
		}
		else if (iPhoneType == 'max tối') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MaxDark.css" type="text/css" >');
		}
		else if (iPhoneType == 'max trong') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MaxTransparent.css" type="text/css" >');
		}
		else if (iPhoneType == 'x mờ') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/XBlur.css" type="text/css" >');
		}
		else if (iPhoneType == 'x sáng') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/XLight.css" type="text/css" >');
		}
		else if (iPhoneType == 'x tối') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/XDark.css" type="text/css" >');
		}
		else if (iPhoneType == 'x trong') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/XTransparent.css" type="text/css" >');
		}
		else if (iPhoneType == 'plus mờ') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/PlusBlur.css" type="text/css" >');
		}
		else if (iPhoneType == 'plus sáng') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/PlusLight.css" type="text/css" >');
		}
		else if (iPhoneType == 'plus tối') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/PlusDark.css" type="text/css" >');
		}
		else if (iPhoneType == 'plus trong') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/PlusTransparent.css" type="text/css" >');
		}
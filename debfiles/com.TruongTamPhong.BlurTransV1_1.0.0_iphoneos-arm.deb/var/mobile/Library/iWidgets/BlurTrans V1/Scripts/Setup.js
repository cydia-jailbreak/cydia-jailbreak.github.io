var language, weekday, smonth, Fcondition;
if (language === "vn") {
weekday = ["CN, ", "Thứ 2, ", "Thứ 3, ", "Thứ 4, ", "Thứ 5, ", "Thứ 6, ", "Thứ 7, "];
    smonth = ["Thg 1 ", "Thg 2", "Thg 3", "Thg 4", "Thg 5", "Thg 6", "Thg 7", "Thg 8", "Thg 9", "Thg 10", "Thg 11", "Dec"];
Fcondition = ["blank"];
}
if (language === "en") {
   weekday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
   smonth = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
Fcondition = ["blank"];
}
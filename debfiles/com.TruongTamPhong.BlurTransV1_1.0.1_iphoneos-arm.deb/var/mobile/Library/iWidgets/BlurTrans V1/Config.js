var twentyfour = true; // Định dạng thời gian 12h hoặc 24h.
var refresh = 5000; // Thời gian làm mới. Tính bằng Mili giây. (1000 = 1s).
var weathercode = "VMXX0006"; // Đi đến weather.com để lấy mã thành phố của bạn.
var celsius = true; // Độ C.
var gpsswitch = true; // Sử dụng GPS cho thời tiết.
var refreshrate = 30; // Thời gian cập nhật thời tiết. Tính bằng Phút.
var language = "vn"; // Chọn ngôn ngữ cho Lịch: vn (Tiếng Việt), en (Tiếng Anh).

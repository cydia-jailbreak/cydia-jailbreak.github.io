(function(window, doc) {
	
	//Options.plist
	// var width = 310;
   // var height = 460;
	// var bgcolor = "white";
	// var	borderradius = 10;
   // var border = "dashed";
    var container = doc.getElementById('container');
        container.style.width = width + "px";
        container.style.height = height + "px";
        container.style.backgroundColor = bgcolor;
        container.style.border = border;
        container.style.borderRadius = borderradius + "px";

}(window, document));
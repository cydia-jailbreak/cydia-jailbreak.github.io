/* */ var savedElements = {"overlay":"","placedElements":{
"boxZezo":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"40px"},

"boxOne":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"80px"},

"boxTwo":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"120px"},

"boxThree":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"160px"},

"boxFor":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"200px"},

"boxFive":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"240px"},

"boxSix":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"280px"},

"boxSeven":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"320px"},

"boxEight":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"360px"},

"boxNine":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"400px"},

"boxTen":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"440px"},

"boxEleven":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"480px"},

"boxTwelve":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"520px"},

"boxThirteen":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"560px"},

"boxForteen":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"600px"},

"boxFifteen":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"640px"},

"boxSixteen":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"680px"},

"boxSeventeen":{"left":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"720px"},

"boxEightteen":{"left":"2px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"760px"},






"boxZez":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"40px"},

"boxOn":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"80px"},

"boxTw":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"120px"},

"boxThre":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"160px"},

"boxFo":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"200px"},

"boxFiv":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"240px"},

"boxSi":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"280px"},

"boxSeve":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"320px"},

"boxEigh":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"360px"},

"boxNin":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"400px"},

"boxTe":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"440px"},

"boxEleve":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"480px"},

"boxTwelv":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"520px"},

"boxThirtee":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"560px"},

"boxFortee":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"600px"},

"boxFiftee":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"640px"},

"boxSixtee":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"680px"},

"boxSeventee":{"right":"-1px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"720px"},

"boxEighttee":{"right":"2px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"760px"},





"boxNineteen":{"right":"36px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"791px"},

"boxTwenty":{"right":"76px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"791px"},

"boxTwentyOne":{"right":"116px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"791px"},

"boxTwentyTwo":{"right":"156px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"791px"},

"boxTwentyThree":{"left":"36px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"791px"},

"boxTwentyFor":{"left":"76px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"791px"},

"boxTwentyFive":{"left":"116px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"791px"},

"boxTwentySix":{"left":"156px","border-color":"#E8E8E8","border-width":"5px","position":"absolute","border-radius":"30px","width":"10px","box-shadow":"#ffffff 0px 0px 0px","height":"10px", "-webkit-transform":"rotate(90deg)","z-index":"0","border-style":"solid","top":"791px"},

} ,"iconName":"StartNotch"}




"use strict";
options.seconds = false;
options.disableweather = false;
options.disableoverlay = false;
options.clockrefresh = 1000;
options.languages = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en';

var translate = {
    en: {
        weekday: ["Chủ Nhật,", "Thứ Hai,", "Thứ Ba,", "Thứ Tư,", "Thứ Năm,", "Thứ Sáu,", "Thứ Bảy,"],
        smonth: ["tháng 1", "tháng 2", "tháng 3", "tháng 4", "tháng 5", "tháng 6", "tháng 7", "tháng 8", "tháng 9", "tháng 10", "tháng 11", "tháng 12"]
    }
};

try {
    if (!translate[options.languages]) {
        options.languages = 'en';
    }
} catch (err) {
    //alert("setup err" + err);
}
if (options.seconds === true) {
    options.clockrefresh = 1000;
}


function convertTOWord(num) {
    var onesText = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'],
        tensText = ['', '', 'twenty', 'thirty', 'fourty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'],
        aboveText = ['', ' thousand ', ' million ', ' billion ', ' trillion ', ' quadrillion ', ' quintillion ', ' sextillion '],
        generatedArray = [],
        converted = '',
        i = 0;
    while (num) {
        generatedArray.push(num % 1000);
        num = parseInt(num / 1000, 10);
    }
    while (generatedArray.length) {
        converted = (function (a) {
            var x = Math.floor(a / 100),
                y = Math.floor(a / 10) % 10,
                z = a % 10;
            return (x > 0 ? onesText[x] + ' hundred ' : '') +
                (y >= 2 ? tensText[y] + ' ' + onesText[z] : onesText[10 * y + z]);
        })(generatedArray.shift()) + aboveText[i++] + converted;
    }
    return converted;
}

function checkDiv(div) { //check if element is placed
    var keys = Object.keys(action.savedElements.placedElements),
        loc = keys.indexOf(div);
    if (loc !== -1) {
        return document.getElementById(keys[loc]);
    }
    return;
}

/* */ var savedElements = {"overlay":"","placedElements":{


"boxOne":{"left":"5px","border-color":"rgb(232, 232, 232)","border-width":"1px","position":"absolute","border-radius":"30px","width":"305px","-webkit-transform":"rotate(-0.1deg)","box-shadow":"0px 0px 0px rgb(36, 36, 36)","height":"104px","background-color":"rgba(102, 102, 102, 0.30)","z-index":"0","border-style":"solid","top":"575px"},

"boxThree":{"left":"25px","border-color":"rgb(130, 130, 130)","border-width":"0.5px","position":"absolute","border-radius":"10px","width":"265px","-webkit-transform":"rotate(-0.1deg)","box-shadow":"0px 0px 0px rgb(36, 36, 36)","height":"19px","background-color":"rgba(151, 151, 151, 0.30)","z-index":"0","border-style":"solid","top":"583px"},


"boxTwo":{"left":"33px","border-color":"red","border-width":"0px","position":"absolute","border-radius":"320px","width":"6px","-webkit-transform":"rotate(-0.1deg)","height":"6px","background-color":"rgb(32, 178, 170)","z-index":"1","border-style":"solid","top":"590px"},


"tempdeg":{"height":"19px","color":"white","font-family":"helvetica","position":"absolute","width":"24px","-webkit-transform":"rotate(-0.1deg)","z-index":"2","font-size":"10px","top":"585.5px","left":"250px"},


"icon":{"top":"586px","z-index":"2","width":"12px","position":"absolute","left":"269px"},





"city":{"height":"13px","color":"white","font-family":"helvetica","position":"absolute","width":"63px","-webkit-transform":"rotate(-0.1deg)","z-index":"2","font-size":"10px","top":586,"left":"50px"}},"iconName":"simply"}



var time = "24h"; // Chọn định dạng "12h" hoặc "24h".

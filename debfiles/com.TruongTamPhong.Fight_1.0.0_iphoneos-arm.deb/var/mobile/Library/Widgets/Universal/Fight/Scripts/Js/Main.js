var checkSettings= function() {
document.getElementById("Clock").style.color = ClockColor;}  
checkSettings();
document.documentElement.style.setProperty('--fsT', fsT + 'px');
document.documentElement.style.setProperty('--shC', shC);
if(gf === 0){
document.getElementById('Gif').style.display = 'none';}
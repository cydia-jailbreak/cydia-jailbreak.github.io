var checkSettings= function() {
document.getElementById("Calendar").style.color = CalendarColor;
document.getElementById("Clock").style.color = ClockColor;}  
checkSettings();
if(gf === 0){
document.getElementById('Gif').style.display = 'none';}
document.documentElement.style.setProperty('--gifY', gifY + 'px');
if(ca === 0){
document.getElementById('Calendar').style.display = 'none';}
document.documentElement.style.setProperty('--fsC', fsC + 'px');
if(cl === 0){
document.getElementById('Clock').style.display = 'none';}
document.documentElement.style.setProperty('--fsT', fsT + 'px');
document.documentElement.style.setProperty('--shT', shT);

$('head').removeAttr('Style');
if (Style == 'Lay') {
$ ('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/Lay.css" type="text/css" >');
}
else if (Style == 'Stand') {
$ ('head').append('<link rel="stylesheet" media="screen" href="Scripts/Css/Stand.css" type="text/css" >');
}
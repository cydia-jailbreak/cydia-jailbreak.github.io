var time = false; // BẬT chuyển sang định dạng 24h. TẮT chuyển sang định dạng 12h

var IconSet = "Wt";
var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'vi',
    $$ = function (el) {
        return document.getElementById(el);
    },
   translate = {
        vi: {
            smonth: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"],
            day: ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"],
            sday: ["Cn", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"],
            condition: ["Có bão", "Bão nhiệt đới", "Có bão", "Có dông", "Có dông", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Mưa rào", "Có mưa", "Có bão", "Mưa tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù", "Sương nhẹ", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây vài nơi", "Trời nhiều mây", "Trời nhiều mây", "Có mây vài nơi", "Có mây vài nơi", "Quang mây", "Có nắng", "Trời quang mây", "Trời nắng", "Mưa đá", "Trời nóng", "Có sấm sét", "Có sấm sét", "Có sấm sét", "Có mưa", "Có tuyết", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "blank"], charging: ["Pin còn lại" , "Đang sạc"]

	}};
if (!translate[current]){current = 'vi';}
Lang = lang;
if (Lang == "vi") {
var days = ["Chu", "Thu", "Thu", "Thu", "Thu", "Thu", "Thu"];
var shortdays = ["Nhật", "Hai", "Ba", "Tư", "Năm", "Sáu", "Bảy"];
var months = ["Tháng một", "Tháng hai", "Tháng ba", "Tháng tư", "Tháng năm", "Tháng sáu", "Tháng bảy", "Tháng tám", "Tháng chín", "Tháng mười", "Tháng mười một", "Tháng mười hai"];
var charging = "⚡";
var notcharging = "";
var titletext = "♫ Music ♫";
var artisttext = "Không có nghệ sĩ";
}

if (Lang == "en") {
var days = ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Saturday"];
var shortdays = ["Day", "Day", "Day", "Day", "Day", "Day", "Day"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var charging = "⚡";
var notcharging = "";
var titletext = "♫ Music ♫";
var artisttext = "No Artists";
}
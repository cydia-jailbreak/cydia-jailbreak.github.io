function TP(){{}
checkSettings();}

function checkSettings(){
document.documentElement.style.setProperty('--PrimaryColor', '#' + PrimaryColor);
document.documentElement.style.setProperty('--SecondaryColor', '#' + SecondaryColor);

/*---- Battery ----*/
if(Percent === 0){
document.getElementById('Percent').style.display = 'none';}

/*---- Dock ----*/
if(Dock === 0){
document.getElementById('Dock').style.display = 'none';}

if(DockLR === 0){
document.getElementById('DockLeft').style.display = 'none';
document.getElementById('DockRight').style.display = 'none';}


/*---- Search ----*/
if(se === 0){
document.getElementById('SearchCont').style.display = 'none';}
document.getElementById("In").placeholder = ph;}


var input = document.getElementById("In");
input.addEventListener("keyup", function(event) {
if (event.keyCode === 13) {event.preventDefault();
Search();}});

function Search(){
var input = document.getElementById("In").value;
if(input.trim() !== ''){
window.location = 'https://www.google.com.vn/search?q=' + input;
document.getElementById("In").value = "";}}
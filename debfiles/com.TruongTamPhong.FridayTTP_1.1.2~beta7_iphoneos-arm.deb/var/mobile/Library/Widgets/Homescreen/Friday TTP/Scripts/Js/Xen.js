function mainUpdate(type){
if (type === "battery"){updateBattery();
} else {
if (type === "music"){checkMusic();
} else {
if (type == "statusbar"){
sigBars(wifiBars, "wifi");
sigBars(signalBars, "carr");
document.getElementById("Net").innerHTML = signalNetworkType;}}}

/*----Signal & Wifi----*/
function sigBars(_curr, name){
if(name === "wifi"){
if(_curr === "0"){
document.getElementById("WiS1").style.opacity = 0.2;
document.getElementById("WiS2").style.opacity = 0.2;
document.getElementById("WiS3").style.opacity = 0.2;}
if(_curr === "1"){
document.getElementById("WiS1").style.opacity = 1;
document.getElementById("WiS2").style.opacity = 0.2;
document.getElementById("WiS3").style.opacity = 0.2;}
if(_curr === "2"){
document.getElementById("WiS1").style.opacity = 1;
document.getElementById("WiS2").style.opacity = 1;
document.getElementById("WiS3").style.opacity = 0.2;}
if(_curr === "3"){
document.getElementById("WiS1").style.opacity = 1;
document.getElementById("WiS2").style.opacity = 1;
document.getElementById("WiS3").style.opacity = 1;}}
if(name === "carr"){
if(_curr === "0"){
document.getElementById("CaS1").style.opacity = 0.2;
document.getElementById("CaS2").style.opacity = 0.2;
document.getElementById("CaS3").style.opacity = 0.2;
document.getElementById("CaS4").style.opacity = 0.2;}
if(_curr === "1"){
document.getElementById("CaS1").style.opacity = 1;
document.getElementById("CaS2").style.opacity = 0.2;
document.getElementById("CaS3").style.opacity = 0.2;
document.getElementById("CaS4").style.opacity = 0.2;}
if(_curr === "2"){
document.getElementById("CaS1").style.opacity = 1;
document.getElementById("CaS2").style.opacity = 1;
document.getElementById("CaS3").style.opacity = 0.2;
document.getElementById("CaS4").style.opacity = 0.2;}
if(_curr === "3"){
document.getElementById("CaS1").style.opacity = 1;
document.getElementById("CaS2").style.opacity = 1;
document.getElementById("CaS3").style.opacity = 1;
document.getElementById("CaS4").style.opacity = 0.2;}
if(_curr === "4"){
document.getElementById("CaS1").style.opacity = 1;
document.getElementById("CaS2").style.opacity = 1;
document.getElementById("CaS3").style.opacity = 1;
document.getElementById("CaS4").style.opacity = 1;}}}
var activate = true;


/*----Name----*/
document.getElementById('YourName').innerHTML = YourName;}


/*----Battery----*/
function updateBattery(){
document.getElementById("Percent").innerHTML = batteryPercent;
document.getElementById("Charging").innerHTML = (batteryCharging) ? charging : notcharging;}


/*----Music----*/
function checkMusic(){
if (isplaying === 1) {		document.getElementById('PlayPause').classList.remove("zeek-buttonplay");		document.getElementById('PlayPause').classList.add("zeek-buttonpause");
} else {		document.getElementById('PlayPause').classList.remove("zeek-buttonpause");		document.getElementById('PlayPause').classList.add("zeek-buttonplay");
}

if(title === "(null)"){
document.getElementById('Artist').innerHTML = artisttext;
document.getElementById('Title').innerHTML = titletext;
} else {
document.getElementById('Artist').innerHTML = artist;
document.getElementById('Title').innerHTML = title;

if (checkOverflow(document.getElementById('Title')) === true){
document.getElementById('Title').classList.add("marquee");
} else {
document.getElementById('Title').classList.remove("marquee");}
}

if(album === "(null)"){
document.getElementById('Album').src = 'Scripts/Js/Blank.js';
} else {		
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();

if (xhr.status === "404") {
document.getElementById('Album').src = 'Scripts/Js/Blank.js';
} else {
document.getElementById('Album').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();
}}}

function checkOverflow(el) {
var curOverflow = el.style.overflow;
if ( !curOverflow || curOverflow === "visible" ){
el.style.overflow = "hidden"; 
}

var isOverflowing = el.clientWidth < el.scrollWidth || el.clientHeight < el.scrollHeight;
el.style.overflow = curOverflow;
return isOverflowing; 
} 

function playPause() {
if(
document.getElementById('PlayPause').classList.contains("zeek-buttonplay")){ 
document.getElementById('PlayPause').classList.remove("zeek-buttonplay");
document.getElementById('PlayPause').classList.add("zeek-buttonpause");
} else { 
document.getElementById('PlayPause').classList.remove("zeek-buttonpause");
document.getElementById('PlayPause').classList.add("zeek-buttonplay");}

window.location = 'xeninfo:playpause';
document.getElementById('PlayPause').style.opacity = 0;
setTimeout(function (){
document.getElementById('PlayPause').style.opacity = 1;
}, 300);
}
		
function next() {
window.location = 'xeninfo:nexttrack';
document.getElementById('Next').style.opacity = 0;
setTimeout(function (){
document.getElementById('Next').style.opacity = 1;
}, 200);
}
			
function prev() {
window.location = 'xeninfo:prevtrack';
document.getElementById('Prev').style.opacity = 0;
setTimeout(function (){
document.getElementById('Prev').style.opacity = 1;
}, 200);
}
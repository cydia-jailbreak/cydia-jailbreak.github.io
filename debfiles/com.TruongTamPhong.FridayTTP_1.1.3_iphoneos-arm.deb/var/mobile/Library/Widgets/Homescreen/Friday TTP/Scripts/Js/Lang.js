Lang = lang;
if (Lang == "vi") {
var days = ["Chủ", "Thứ", "Thứ", "Thứ", "Thứ", "Thứ", "Thứ"];
var shortdays = ["Nhật", "Hai", "Ba", "Tư", "Năm", "Sáu", "Bảy"];
var months = ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "05", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"];
var charging = "⚡";
var notcharging = "";
var titletext = "♫ Music ♫";
var artisttext = "Không có nghệ sĩ";
}

if (Lang == "en") {
var days = ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Saturday"];
var shortdays = ["Day", "Day", "Day", "Day", "Day", "Day", "Day"];
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var charging = "⚡";
var notcharging = "";
var titletext = "♫ Music ♫";
var artisttext = "No Artists";
}
options.clockrefresh = 1000;
options.languages = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'vi';
var translate = {
    vi: {
        weekday: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        smonth: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]}}
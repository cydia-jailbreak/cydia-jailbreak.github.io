var action = {};
action.savedElements = {};
action.loadedFonts = [];
action.containsWeather = false;

action.setOverlay = function (img) {
    setTimeout(function () {
        var screenOverDiv, svgdiv;
        screenOverDiv = document.createElement('div');
        screenOverDiv.className = 'screenOverlay';
        screenOverDiv.style.backgroundImage = 'url(' + img + ')';
        document.body.appendChild(screenOverDiv);
        if(iPhoneX){
        }
        if (img.split(';')[0].split('/')[1].split('+')[0] === 'svg') {
            action.loadjsfile("js/svg.js");
            svgdiv = document.createElement('img');
            svgdiv.className = 'svg';
            svgdiv.style.display = 'none';
            svgdiv.style.opacity = '0';
            svgdiv.src = img;
            document.body.appendChild(svgdiv);
        }
    }, 0);
};

action.isWeather = function (id) {

};

action.remakeDIV = function (id) {

    if(document.getElementById(id)){
        return document.getElementById(id);
    }

    var div = document.createElement('div');
    div.id = id;

    if (action.containsWeather === false) {
        action.isWeather(id);
    }

    document.getElementById('screenElements').appendChild(div);
    return div;
};

action.injectFont = function () {
    var css = "",
        i,
        head = document.head || document.getElementsByTagName('head')[0],
        style = document.createElement('style');
    for (i = 0; i < action.loadedFonts.length; i++) {
        if(action.loadedFonts[i] !== 'helvetica'){
            css += "\n@font-face{\nfont-family:'" + action.loadedFonts[i] + "';\nsrc:url('../../../../var/mobile/Documents/lockplusfonts/" + action.loadedFonts[i] + ".otf');\n}";
        }
    }
    style.type = 'text/css';
    if (style.styleSheet) {
        style.styleSheet.cssText = css;
    } else {
        style.appendChild(document.createTextNode(css));
    }
    head.appendChild(style);
};


action.stageFont = function (font) {
    if (action.loadedFonts.indexOf(font) === -1) {
        action.loadedFonts.push(font);
    }
};

action.weatherJSLoaded = function () {
    wlib();
};

action.loadStyles = function(key, value, createdDiv){
    var styleVal;
    Object.keys(value).forEach(function (skey) {

        styleVal = value[skey];

        if (skey === 'data-prefix' || skey === 'data-suffix') {
            createdDiv.setAttribute(skey, styleVal);
        } else {
            createdDiv.style[skey] = styleVal;
        }

        switch(skey) {
            case 'font-family':
                action.stageFont(styleVal);
            break;
            case 'data-vars':
                for (var i = 0; i < styleVal.length; i++) {
                    createdDiv.className = 'customDiv';

                    var div;
                    if(document.getElementById(styleVal[i])){
                        createdDiv.appendChild(document.getElementById(styleVal[i]));
                    }else{
                        div = action.remakeDIV(styleVal[i]);
                        createdDiv.appendChild(div);
                    }
                }
            break;
            default:
            break;
        }
    });
};

action.createIconElementIfNeeded = function(key, createdDiv){
};

action.replaceElements = function () {
    var value, styleVal, createdDiv,
        placedElements = this.savedElements.placedElements;

    Object.keys(placedElements).forEach(function (key) {
        if (placedElements[key].type == 'widget') {
            loadexjsfile(key, true);
            action.isWeather(key);
        } else {
            try{
                createdDiv = action.remakeDIV(key);
            }catch(err){
                alert("createdDiv error " + err);
            }
            try{
                value = placedElements[key];
            }catch(err){
                alert("value error " + err);
            }
            try{
                action.createIconElementIfNeeded(key, createdDiv);
            }catch(err){
                alert("createIcon error " + err);
            }
            try{
                action.loadStyles(key, value, createdDiv);
            }catch(err){
                alert("loadStyles error " + err);
            }
        }
    });

    action.injectFont();
    startLoop();
    action.savedElements.overlay = null;
};

action.loadFromStorage = function () {
    if (localStorage.placedElements) {
        this.savedElements = JSON.parse(localStorage.placedElements);
        if(this.savedElements.overlay != undefined){
            if (this.savedElements.overlay.length > 1) {
                if (!options.disableoverlay) {
                    this.setOverlay(this.savedElements.overlay);
                }
            }
        }
        if (this.savedElements.placedElements) {
                this.replaceElements();
        }
    } else {
        setTimeout(function () {
            action.loadjsfile("js/svg.js");
        }, 100);
    }
};

function loadInfo(){
    action.loadFromStorage();
}
setTimeout(function () {
    loadInfo();
}, 0);

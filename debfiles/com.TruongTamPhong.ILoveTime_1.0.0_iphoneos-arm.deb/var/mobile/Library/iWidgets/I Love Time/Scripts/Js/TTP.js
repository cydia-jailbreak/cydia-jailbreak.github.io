/* */ var savedElements = {"overlay":"","placedElements":{

"zclock":{
"color":"white",
"font-family":"TamPhong",
"position":"absolute",
"text-align":"center",
"width":"188px",
"text-transform":"uppercase",
"z-index":"2",
"font-size":"13px",
"top":"170px",
"left":"76px",
"height":"36px",
"letter-spacing":"3",
},

"daydatesmonth":{
"font-family":"TamPhong",
"z-index":"2",
"color":"white",
"text-align":"center",
"position":"absolute",
"text-transform":"uppercase",
"font-size":"37px",
"top":"120px",
"left":"0px",
"width":"340px",
"height":"16px",
"letter-spacing":"3",
}},}
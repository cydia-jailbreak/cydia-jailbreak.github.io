window.addEventListener("load", function() { 
}, false);
function init(){
	updateClock();
	setInterval("updateClock();", 5000);
	checkSettings();}

function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	var Time24 = 1;
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}

document.getElementById("Time").innerHTML = currentHours + "." + currentMinutes1;
document.getElementById("Month").innerHTML = shortmonths[currentTime.getMonth()];
document.getElementById("Day").innerHTML = currentDate;
document.getElementById("Weekday").innerHTML = shortdays[currentTime.getDay()];}
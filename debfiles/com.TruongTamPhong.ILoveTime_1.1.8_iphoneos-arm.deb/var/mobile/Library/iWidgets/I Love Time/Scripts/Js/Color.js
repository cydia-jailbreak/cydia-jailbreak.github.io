var changeSettings= function() {
document.getElementById("body").style.color = InfoTextColor;
document.getElementById("Calendar").style.color = CalendarColor;
document.getElementById("Time").style.color = TimeColor;
document.getElementById("Love").style.color = LoveColor;
}  
changeSettings();
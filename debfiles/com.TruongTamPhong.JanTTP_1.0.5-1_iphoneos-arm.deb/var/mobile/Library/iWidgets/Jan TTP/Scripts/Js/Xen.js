function mainUpdate(type){ 
if (type == "statusbar"){
if(ba === 1){
sigBars(wifiBars, "wifi");
sigBars(signalBars, "carr");
document.getElementById("net").innerHTML = signalNetworkType;}
}else if (type === "music"){
if(mu === 1)
checkMusic();
}else if (type === "battery"){
if(ba === 1)
updateBattery();}}
function sigBars(_curr, name){
if(name === "wifi"){
if(_curr === "0"){
document.getElementById("wiS1").style.opacity = 0.2;
document.getElementById("wiS2").style.opacity = 0.2;
document.getElementById("wiS3").style.opacity = 0.2;}
if(_curr === "1"){
document.getElementById("wiS1").style.opacity = 1;
document.getElementById("wiS2").style.opacity = 0.2;
document.getElementById("wiS3").style.opacity = 0.2;}
if(_curr === "2"){
document.getElementById("wiS1").style.opacity = 1;
document.getElementById("wiS2").style.opacity = 1;
document.getElementById("wiS3").style.opacity = 0.2;}
if(_curr === "3"){
document.getElementById("wiS1").style.opacity = 1;
document.getElementById("wiS2").style.opacity = 1;
document.getElementById("wiS3").style.opacity = 1;}}
if(name === "carr"){
if(_curr === "0"){
document.getElementById("caS1").style.opacity = 0.2;
document.getElementById("caS2").style.opacity = 0.2;
document.getElementById("caS3").style.opacity = 0.2;
document.getElementById("caS4").style.opacity = 0.2;}
if(_curr === "1"){
document.getElementById("caS1").style.opacity = 1;
document.getElementById("caS2").style.opacity = 0.2;
document.getElementById("caS3").style.opacity = 0.2;
document.getElementById("caS4").style.opacity = 0.2;}
if(_curr === "2"){
document.getElementById("caS1").style.opacity = 1;
document.getElementById("caS2").style.opacity = 1;
document.getElementById("caS3").style.opacity = 0.2;
document.getElementById("caS4").style.opacity = 0.2;}
if(_curr === "3"){
document.getElementById("caS1").style.opacity = 1;
document.getElementById("caS2").style.opacity = 1;
document.getElementById("caS3").style.opacity = 1;
document.getElementById("caS4").style.opacity = 0.2;}
if(_curr === "4"){
document.getElementById("caS1").style.opacity = 1;
document.getElementById("caS2").style.opacity = 1;
document.getElementById("caS3").style.opacity = 1;
document.getElementById("caS4").style.opacity = 1;}}}
var activate = true;
function updateBattery() {
document.getElementById("percentage").innerHTML = batteryPercent;
if(batteryCharging === 0){
document.getElementById("bgCont").style.opacity = batteryPercent * 0.8 / 100;
}else{
if(activate){
activate = false;
document.getElementById("bgCont").style.opacity = 0.2;
setTimeout(function (){
document.getElementById("bgCont").style.opacity = 0.8;
activate = true;}, 2000);}}}
options.clockrefresh = 1000;
options.languages = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'vi';
var translate = {
    vi: {
        weekday: ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"],
        smonth: ["tháng 1", "tháng 2", "tháng 3", "tháng 4", "tháng 5", "tháng 6", "tháng 7", "tháng 8", "tháng 9", "tháng 10", "tháng 11", "tháng 12"]}}
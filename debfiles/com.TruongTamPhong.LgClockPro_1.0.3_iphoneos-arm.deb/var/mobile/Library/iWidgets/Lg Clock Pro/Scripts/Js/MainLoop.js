var date,
	loopTimer = 1000,
    iOSClockTimer = "0:00";

function setElementInfo(div, value){
	var innerHTML = div.innerHTML.replace('°', '&deg;'),
		innerTEXT = div.innerText.replace('°', '&deg;');
    if(innerHTML === value || innerTEXT === value){
        return;
    }
    if (String(value).indexOf(';') > -1) {
        div.innerHTML = value;
    } else {
        div.innerText = value;
    }
};

function mainLoop(option) {
    var getInfo = function() {
        date = new Date();
            option.success();
        setTimeout(function() {
            getInfo();
        }, loopTimer);
    };
    getInfo();
}

function getClockInfo(key){
	var value = "";
	clockElements[key].forEach(function(info) {
        if (clockMethods[info]) {
            value += clockMethods[info]();
        } else {
            value += info;
        }
    });
    return value;
}

function startLoop() {
    mainLoop({
        success: function() {
            'use strict';
            var div, prefix, suffix, value;
            Object.keys(action.savedElements.placedElements).forEach(function(key) {
            	if(weatherElements[key] || clockElements[key] || systemElements[key]){
            		div = document.getElementById(key);
	                prefix = div.getAttribute('data-prefix') || '';
	                suffix = div.getAttribute('data-suffix') || '';
	                value = "";
            	}
                if (weatherElements[key]) {
                    try{
                	value = getWeatherInfo(key);
                    if(String(key).indexOf('icon') == -1){
                        value = prefix + value + suffix;
                        setElementInfo(div, value);
                    }
                    }catch(err){
                        //alert(err);
                    }
                }else if (clockElements[key]) {
                    value = prefix + getClockInfo(key) + suffix;
                    setElementInfo(div, value);
                }else if (systemElements[key]){
                	if(key.substring(0, 3) != 'box'){
                		value = prefix + getSystemInfo(key) + suffix;
                    	setElementInfo(div, value);
                	}
		           
                }
            });
        }
    });
}
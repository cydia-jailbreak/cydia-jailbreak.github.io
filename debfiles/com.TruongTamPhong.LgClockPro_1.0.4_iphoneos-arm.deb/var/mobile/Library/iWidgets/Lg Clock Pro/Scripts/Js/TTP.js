/* */ var savedElements = {"overlay":"","placedElements":{

"zclock":{
"color":"white",
"font-family":"TruongTamPhong",
"position":"absolute",
"text-align":"center",
"width":"88px",
"background-color":"#none",
"font-weight":"900",
"z-index":"2",
"font-size":"30px",
"top":"72px",
"left":"116px",
"height":"36px",
"-webkit-transform":"rotate(0deg)"
},

"boxOne":{
"height":"1px",
"border-color":"red",
"position":"absolute",
"width":"88px",
"border-width":"0px",
"background-color":"rgba(150,150,150, 1)",
"z-index":"100",
"top":"107px",
"border-style":"solid",
"left":"115px",
"border-radius":"0px",
"-webkit-transform":"rotate(0deg)"
},

"day":{"color":"white",
"font-family":"TamPhong",
"position":"absolute",
"text-align":"center",
"width":"88px",
"background-color":"#none",
"z-index":"2",
"font-size":"12px",
"top":"109px",
"left":"115px",
"height":"16px",
"-webkit-transform":"rotate(0deg)"
},

"daydatesmonth":{
"font-family":"TamPhong",
"z-index":"2",
"color":"white",
"text-align":"center",
"position":"absolute",
"font-size":"11px",
"top":"127px",
"left":"123px",
"width":"72px",
"background-color":"#FF0055",
"border-radius":"10px",
"height":"16px",
"-webkit-transform":"rotate(0deg)"
},

"boxCircleOne":{
"left":"95px",
"border-color":"rgb(222,222,222)",
"border-width":"2px",
"position":"absolute",
"border-radius":"100%",
"width":"125px",
"height":"125px",
"box-shadow":"#000 0px 0px 9px",
"background-color":"rgba (20,20,20, 0)",
"z-index":"1",
"border-style":"solid",
"top":"45px"
}
},"iconName":"simply"}
/* */ var savedElements = {"overlay":"","placedElements":{"zclock":{"color":"white","font-family":"TruongTamPhong","position":"absolute","text-align":"center","width":"310px","font-weight":"900","z-index":"2","font-size":"30px","top":70,"left":"4.2px","height":"36px","-webkit-transform":"rotate(0deg)"},"day":{"color":"white","font-family":"TamPhong","position":"absolute","text-align":"center","width":"310px","z-index":"2","font-size":"15px","top":"107px","left":"4px","height":"24px","-webkit-transform":"rotate(0deg)"},"smonth":{
      "z-index":"2",
      "left":"144px",
      "color":"white",
      "font-family":"TamPhong",
      "font-size":"15px",
      "top":"125px",},
"boxOne":{"height":"1px","border-color":"red","position":"absolute","width":"80px","border-width":"0px","background-color":"rgb(255, 255, 255)","z-index":"1","top":"105px","border-style":"solid","left":"118px","border-radius":"0px","-webkit-transform":"rotate(0deg)"},
"boxCircleOne":{"left":"89px","border-color":"rgb(255, 255, 255)","border-width":"2px","position":"absolute","border-radius":"320px","width":"135px","box-shadow":"rgb(255,255,255) 0px 0px 15px","background":"linear-gradient(150deg,rgba(0,0,0,0.227451),rgba(0,0,0,0.227451) 50%,rgba(0, 0, 0, 0.22) 90%)","height":"135px","background-color":"rgba(255, 0, 0, 0)","z-index":"1","border-style":"solid","top":40,"-webkit-transform":"rotate(0deg)"},
"datepad":{"font-family":"TamPhong","z-index":"2","color":"white","position":"absolute","font-size":"15px","top":"125px","left":"127px","width":"34px","height":"36px","-webkit-transform":"rotate(0deg)"}},"iconName":"simply"}
var options = {
  },
  cycript = {},
  injectedWeather = {},
  injectedSystem = {},
  injectedMusic = {},
  mainTarget = localStorage.themeName,
  appToOpen = null,
  urlToOpen = null,
  wallpaperSet = false,
  weather = null,
  percent = ['0', '40', '60', '100'],
  albumArtAdded = false,
  screenShowing,
  pressOptions;

  setTimeout(function(){
    pressOptions = action.savedElements.placedElements['pressActions'];
  },1000);
function removeBackgroundAnimation(){
    var bgAnimation = document.getElementById('backgroundAnimation');
    if(bgAnimation){
        document.body.removeChild(bgAnimation);
    }
}
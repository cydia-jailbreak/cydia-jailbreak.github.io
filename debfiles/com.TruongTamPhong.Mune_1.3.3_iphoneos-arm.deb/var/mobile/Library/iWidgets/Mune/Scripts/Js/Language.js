window.requestAnimFrame = (function () {return window.requestAnimationFrame || window.webkitRequestAnimationFrame;}());
function clock(options) { var getTimes = function () { var d = new Date(), funcs = {hour: function () {var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1; hour = (options.padzero === true) ? (hour < 10 ? "0" + hour : "" + hour) : hour; return hour;},
rawhour: function () { return d.getHours();},
minute: function () { return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();},
rawminute: function () { return d.getMinutes();},
ampmstrict: function () { var ampm = (d.getHours() > 11) ? "pm" : "am"; return ampm;},
am: function () { if (options.twentyfour === true) {
return ' ';}
return (d.getHours() > 11) ? "pm" : "am";},
date: function () {return d.getDate();},
day: function () {
return d.getDay();},month: function () {return d.getMonth();},
nth: function (d) {if (d > 3 && d < 21) {return '';}
switch (d % 10) {case 1: return ""; case 2: return ""; case 3: return ""; default: return "";}}};
options.success(funcs);
setTimeout(function () {window.requestAnimFrame(getTimes);}, options.refresh);};getTimes();}
var current = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'vi', $$ = function (el) {return document.getElementById(el);},
translate = {vi: {weekday: ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"], month: ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"]}};
if (!translate[current]) {current = 'vi';}

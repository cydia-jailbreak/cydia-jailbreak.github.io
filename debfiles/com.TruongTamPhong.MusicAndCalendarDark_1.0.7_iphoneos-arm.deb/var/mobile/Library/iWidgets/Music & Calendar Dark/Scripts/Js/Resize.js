if (iPhoneType == "auto") {
        if (screen.height == 667) { iPhoneType = "Min"; }
	else if (screen.height == 736) { iPhoneType = "Plus"; }
	else if (screen.height == 812) { iPhoneType = "X"; }
	else if (screen.height == 896) { iPhoneType = "Max"; }
	else { iPhoneType = "auto"; }
}

window.addEventListener("load", function() { 
	switch(iPhoneType) {
		case "nhỏ":
			document.body.style.width='375px';
			document.body.style.height='667px';
		break;
		case "plus":
			document.body.style.width='414px';
			document.body.style.height='736px';
		break;
		case "x":
			document.body.style.width='375px';
			document.body.style.height='812px';
		break;
		case "max":
			document.body.style.width='414px';
			document.body.style.height='896px';
		break;
	}
}, false);

		$('head').removeAttr('Style');
                if (iPhoneType == 'Min') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/Min.css" type="text/css" >');
		}
		else if (iPhoneType == 'Max') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/Max.css" type="text/css" >');
		}
		else if (iPhoneType == 'X') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/X.css" type="text/css" >');
		}
		else if (iPhoneType == 'Plus') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/Plus.css" type="text/css" >');
		}
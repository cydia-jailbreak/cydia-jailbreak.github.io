var iPhoneType = "auto"; //Chọn "auto" hoặc "iPh6" hoặc "iPhPlus" hoặc "iPhX" hoặc "iPhXMax"

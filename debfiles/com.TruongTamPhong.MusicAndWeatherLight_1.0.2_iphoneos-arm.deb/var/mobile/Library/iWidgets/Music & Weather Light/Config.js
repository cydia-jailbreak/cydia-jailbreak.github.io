var iPhoneType = "iPhPlus"; //Chọn "auto" hoặc "iPh6" hoặc "iPhPlus" hoặc "iPhX" hoặc "iPhXMax"

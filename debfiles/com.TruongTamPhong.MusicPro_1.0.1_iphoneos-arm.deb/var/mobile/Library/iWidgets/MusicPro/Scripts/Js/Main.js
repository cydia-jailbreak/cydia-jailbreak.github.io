function mainUpdate(type){ 
if (type === "music"){
		if(mu === 1)
			checkMusic();}}
window.addEventListener("load", function() { 
}, false);
function openApp(){
	window.location = 'xeninfo:openapp:' + mb;
}
var mus = document.getElementById('musCont');
var gen = document.getElementById('genCont');
function openWid(){
	if(one === 1){
		if(mus.classList.contains('closed')){
			mus.classList.remove('closed');
			mus.classList.add('open');
			gen.classList.remove('open');
			gen.classList.add('closed');
			mus.style.zIndex = 0;
			gen.style.zIndex = -1;
			mus.style.display = 'block';
			TweenMax.to(mus, 0.5, {alpha:1});
			TweenMax.to(gen, 0.5, {alpha:0, onComplete:function(){
			gen.style.display = 'none';	
			}});
document.getElementById('mArt').classList.remove('closed');
document.getElementById('infoCont').classList.remove('closed');
document.getElementById('controls').classList.remove('closed');
			return;
		}else{
			mus.classList.add('closed');
			mus.classList.remove('open');
			gen.classList.remove('closed');
			gen.classList.add('open');
			mus.style.zIndex = -1;
			gen.style.zIndex = 0;
			gen.style.display = 'block';
			TweenMax.to(gen, 0.5, {alpha:1});
			TweenMax.to(mus, 0.5, {alpha:0, onComplete:function(){
			mus.style.display = 'none';	
			}});
document.getElementById('mArt').classList.add('closed');
document.getElementById('infoCont').classList.add('closed');
document.getElementById('controls').classList.add('closed');
return;}}
}
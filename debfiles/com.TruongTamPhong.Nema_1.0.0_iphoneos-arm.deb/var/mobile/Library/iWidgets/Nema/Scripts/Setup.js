
"use strict";
options.seconds = false;
options.disableweather = false;
options.disableoverlay = false;
options.clockrefresh = 1000;
options.languages = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'vn';
var translate = {
    vn: {
        weekday: ["Chủ Nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"],
        condition: ["Có bão", "Bão nhiệt đới", "Có bão", "Có dông", "Có dông", "Có tuyết", "Mưa đá", "Mưa đá", "Mưa phùn lạnh", "Mưa phùn", "Mưa lạnh", "Có mưa", "Có mưa", "Có bão", "Có tuyết", "Có tuyết", "Có tuyết", "Mưa đá", "Mưa tuyết", "Gió bụi", "Sương mù dày", "Sương mù", "Sương nhẹ", "Gió mạnh", "Có gió", "Trời lạnh", "Có mây", "Có mây", "Có mây", "Có mây", "Có mây", "Trời trong", "Trời nắng", "Trời đẹp", "Trời đẹp", "Mưa đá", "Trời nóng", "Có sấm sét", "Có sấm sét", "Có sấm sét", "Có mưa", "Đang tải", "Tuyết rơi nhẹ", "Tuyết rơi nhiều", "Ít mây", "Có dông", "Có tuyết", "Có dông", "blank"]
    },
};

try {
    if (!translate[options.languages]) {
        options.languages = 'vn';
    }
} catch (err) {
    //alert("setup err" + err);
}
if (options.seconds === true) {
    options.clockrefresh = 1000;
}
function convertTOWord(num) {
        generatedArray = [],
        converted = '',
        i = 0;
    while (num) {
        generatedArray.push(num % 1000);
        num = parseInt(num / 1000, 10);
    }
    while (generatedArray.length) {
        converted = (function (a) {
            var x = Math.floor(a / 100),
                y = Math.floor(a / 10) % 10,
                z = a % 10;
            return (x > 0 ? onesText[x] + ' hundred ' : '') +
                (y >= 2 ? tensText[y] + ' ' + onesText[z] : onesText[10 * y + z]);
        })(generatedArray.shift()) + aboveText[i++] + converted;
    }
    return converted;
}
function checkDiv(div) { //check if element is placed
    var keys = Object.keys(action.savedElements.placedElements),
        loc = keys.indexOf(div);
    if (loc !== -1) {
        return document.getElementById(keys[loc]);
    }
    return;
}

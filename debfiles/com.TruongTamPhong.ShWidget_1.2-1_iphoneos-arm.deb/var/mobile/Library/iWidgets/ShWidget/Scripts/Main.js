{
	var iOSdetail=navigator.appVersion.split(' ')[5];
	iOSdetail = iOSdetail.replace(/_/g, ".");
	var device = navigator.platform;
	
	document.getElementById("iosval").innerHTML = getiPhoneModel() + " &nbsp; ";
}

  
function getiPhoneModel() {
   
    var canvas = document.createElement("canvas");
    if (canvas) {
        var context = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
        if (context) {
            var info = context.getExtension("WEBGL_debug_renderer_info");
            if (info) {
                var renderer = context.getParameter(info.UNMASKED_RENDERER_WEBGL);}}}
if ((window.screen.height / window.screen.width == 812 / 375) && (window.devicePixelRatio == 3)){}else {
        return "iPHONE";
    }
}
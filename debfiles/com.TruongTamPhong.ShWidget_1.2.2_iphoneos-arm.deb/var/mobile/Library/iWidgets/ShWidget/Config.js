var time = true; // Kích hoạt chuyển sang định dạng 24h
var padzero = true; // Kích hoạt thêm số 0 vào trước giờ

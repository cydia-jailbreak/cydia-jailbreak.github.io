var YourName = "Trương Tam Phong"; // Tên của bạn
var MainTextColor = "#dddddd"; // Màu chính
var HighlightColor = "#ff0000"; // Màu phụ
var ShowWidget = true; // Hiện hoặc ẩn Widget

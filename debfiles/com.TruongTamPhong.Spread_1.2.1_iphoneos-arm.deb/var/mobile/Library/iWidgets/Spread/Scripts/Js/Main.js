var Clock = "12h";
var Lang = "en";
window.addEventListener("load", function() { 
}, false);
function init(){
	updateClock();
	setInterval("updateClock();", 5000);
	checkSettings();}

function dark(x) {
  if (x.matches) { 
	setDark();
  }
}
function light(y) {
  if (y.matches) { 
	setLight();
  }
}

function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	var Time24 = 1;
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	document.getElementById("time").innerHTML = currentHours + ":" + currentMinutes1;
	document.getElementById("date").innerHTML = currentDate + " " + months[currentTime.getMonth()];	
}
function openApp(){
	window.location = 'xeninfo:openapp:' + mb;
}
var mus = document.getElementById('musCont');
var gen = document.getElementById('genCont');
function openWid(){
	if(one === 1){
		if(mus.classList.contains('closed')){
			mus.classList.remove('closed');
			mus.classList.add('open');
			gen.classList.remove('open');
			gen.classList.add('closed');
			mus.style.zIndex = 0;
			gen.style.zIndex = -1;
			mus.style.display = 'block';
			TweenMax.to(mus, 0.5, {alpha:1});
			TweenMax.to(gen, 0.5, {alpha:0, onComplete:function(){
			gen.style.display = 'none';	
			}});
document.getElementById('mArt').classList.remove('closed');
document.getElementById('infoCont').classList.remove('closed');
document.getElementById('controls').classList.remove('closed');
document.getElementById('date').classList.add('closed');
document.getElementById('weaCont').classList.add('closed');
document.getElementById('batCont').classList.add('closed');
			return;
		}else{
			mus.classList.add('closed');
			mus.classList.remove('open');
			gen.classList.remove('closed');
			gen.classList.add('open');
			mus.style.zIndex = -1;
			gen.style.zIndex = 0;
			gen.style.display = 'block';
			TweenMax.to(gen, 0.5, {alpha:1});
			TweenMax.to(mus, 0.5, {alpha:0, onComplete:function(){
			mus.style.display = 'none';	
			}});
document.getElementById('date').classList.remove('closed');
document.getElementById('weaCont').classList.remove('closed');
document.getElementById('mArt').classList.add('closed');
document.getElementById('infoCont').classList.add('closed');
document.getElementById('controls').classList.add('closed');
return;}}
}
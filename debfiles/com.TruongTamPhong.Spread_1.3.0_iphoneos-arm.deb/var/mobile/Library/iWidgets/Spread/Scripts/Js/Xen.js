function mainUpdate(type){ 
	if(type === "weather"){
		checkWeather();
	}else if (type === "battery"){
		updateBattery();	  	
	}else if (type === "music"){
		if(mu === 1)
			checkMusic();}}
function checkWeather(){
       document.getElementById('weatherIcon').src = 'Scripts/Weather/' + IconSet + '/' + weather.conditionCode + '.png';
       document.getElementById('condition').innerHTML = condition[weather.conditionCode];
	document.getElementById('tempe').innerHTML = weather.temperature + 'º';}
function updateBattery() {
	document.getElementById("percent").innerHTML = 'Mức pin còn lại: ' + batteryPercent + '%';
	document.getElementById("bl2").style.width = batteryPercent + '%';}
if (iPhoneType == "auto") {
        if (screen.height == 667) { iPhoneType = "mini gold"; }
        else if (screen.height == 667) { iPhoneType = "mini white"; }
	else if (screen.height == 736) { iPhoneType = "plus gold"; }
	else if (screen.height == 736) { iPhoneType = "plus white"; }
	else if (screen.height == 812) { iPhoneType = "x gold"; }
	else if (screen.height == 812) { iPhoneType = "x white"; }
	else if (screen.height == 896) { iPhoneType = "max gold"; }
	else if (screen.height == 896) { iPhoneType = "max white"; }
	else { iPhoneType = "auto"; }
}

window.addEventListener("load", function() { 
	switch(iPhoneType) {
		case "mini gold":
			document.body.style.width='375px';
			document.body.style.height='667px';
		break;
		case "mini white":
			document.body.style.width='375px';
			document.body.style.height='667px';
		break;
		case "plus gold":
			document.body.style.width='414px';
			document.body.style.height='736px';
		break;
		case "plus white":
			document.body.style.width='414px';
			document.body.style.height='736px';
		break;
		case "x gold":
			document.body.style.width='375px';
			document.body.style.height='812px';
		break;
		case "x white":
			document.body.style.width='375px';
			document.body.style.height='812px';
		break;
		case "max gold":
			document.body.style.width='414px';
			document.body.style.height='896px';
		break;
		case "max white":
			document.body.style.width='414px';
			document.body.style.height='896px';
		break;
	}
}, false);

		$('head').removeAttr('Style');
                if (iPhoneType == 'mini gold') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MiniGold.css" type="text/css" >');
		}
		else if (iPhoneType == 'mini white') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MiniWhite.css" type="text/css" >');
		}
		else if (iPhoneType == 'max gold') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MaxGold.css" type="text/css" >');
		}
		else if (iPhoneType == 'max white') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/MaxWhite.css" type="text/css" >');
		}
		else if (iPhoneType == 'x gold') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/XGold.css" type="text/css" >');
		}
		else if (iPhoneType == 'x white') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/XWhite.css" type="text/css" >');
		}
		else if (iPhoneType == 'plus gold') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/PlusGold.css" type="text/css" >');
		}
		else if (iPhoneType == 'plus white') {
		$ ('head').append('<link rel="stylesheet" media="screen" href="Style/PlusWhite.css" type="text/css" >');
		}
/* */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":"2.2px","border-color":"rgb(32,178,170)","border-width":"0.5px","position":"absolute","border-radius":"4.8px","width":"313px","box-shadow":"rgb(32,178,170) 0px 0px 12px","background":"linear-gradient(150deg,rgba(32,178,170,0.35),rgba(255,255,255,0) 50%,rgba(255,50,200,0.30) 90%)","height":"13.5px","background-color":"rgba(0, 0, 0, 0)","z-index":"1","border-style":"solid","top":15,"-webkit-transform":"rotate(0deg)"}},"iconName":"simply"}



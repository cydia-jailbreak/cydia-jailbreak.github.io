/* */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":"8px","border-color":"rgb(255, 255, 255)","border-width":"0.5px","position":"absolute","border-radius":"9.8px","width":"299.5px","box-shadow":"rgba(32,220,220,0.80) 0px 0px 10px","background":"linear-gradient(150deg,rgba(32,178,170,0.50),rgba(255,255,255,0) 50%,rgba(255,50,200, 0.50) 90%)","height":"17px","background-color":"rgba(0, 0, 0, 0)","z-index":"1","border-style":"solid","top":10.5,"-webkit-transform":"rotate(0deg)"}},"iconName":"simply"}



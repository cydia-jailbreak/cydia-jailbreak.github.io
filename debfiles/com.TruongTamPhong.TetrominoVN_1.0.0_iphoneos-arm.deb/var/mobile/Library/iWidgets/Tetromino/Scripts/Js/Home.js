
var highScore = 0;

function checkSettings(){
	
	if (localStorage.getItem('tetro') === null) {
		highScore = 0;
	}else{
		highScore = localStorage.getItem('tetro');
	}
	document.getElementById('highscore').innerHTML = 'Điểm cao<br>' + highScore;
	
	//JsonBid = JSON.stringify(bid);
	//localStorage.setItem('tetro', highScore);
	//localStorage.clear();
	
	document.documentElement.style.setProperty('--primary', C1);
	document.documentElement.style.setProperty('--secondary', C2);
	document.documentElement.style.setProperty('--bg', C3);
	
	
	/*if(muT === 'tp'){
		document.getElementById('musicCont').classList.remove('bottom');
		document.getElementById('musicCont').classList.add('top');
		
		document.getElementById('muInCont').classList.remove('bottom');
		document.getElementById('muInCont').classList.add('top');
		
		document.getElementById('homeCont').classList.remove('bottom');
		document.getElementById('homeCont').classList.add('top');
		
		document.getElementById('elementsHolder').classList.remove('bottom');
		document.getElementById('elementsHolder').classList.add('top');
		
		document.getElementById('elemCont').classList.add('top');
	}else if(muT === 'flb'){
		document.getElementById('elementsHolder').classList.remove('in');
		document.getElementById('elementsHolder').classList.add('out');
		
		document.documentElement.style.setProperty('--fY', fY + 'px');
	}else if(muT === 'fl'){
		document.getElementById('elementsHolder').classList.remove('in');
		document.getElementById('elementsHolder').classList.add('out');
		
		document.documentElement.style.setProperty('--fY', fY + 'px');
		
		document.getElementById('homeCont').classList.remove('bottom');
		document.getElementById('homeCont').classList.add('top');
		
		document.getElementById('musicCont').classList.remove('bottom');
		document.getElementById('musicCont').classList.add('top');
		
		document.getElementById('muInCont').classList.remove('bottom');
		document.getElementById('muInCont').classList.add('top');
	}
	
	if(chC === 'bl'){
		document.documentElement.style.setProperty('--chC', '#1E2035');
	}else if(chC === 're'){
		document.documentElement.style.setProperty('--chC', '#C6140F');
	}else if(chC === 'wh'){
		document.documentElement.style.setProperty('--chC', '#FFFFFF');
	}else if(chC === 'bla'){
		document.documentElement.style.setProperty('--chC', '#393939');
	}else if(chC === 'go'){
		document.documentElement.style.setProperty('--chC', '#F8D296');
	}
	
	document.getElementById("message").innerHTML = msg;
	*/
	
	
	
}




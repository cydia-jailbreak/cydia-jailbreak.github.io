
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);


//var co = 0;
//var timer, timer2, longPress = false;

function init(){
	
	checkSettings();
	createGrid();
	
}

function createGrid(){
	for(var i=0; i<200; i++){
		var gr = document.createElement('div');
		gr.classList = 'grIn';
		
		document.getElementById('tetrisGrid').appendChild(gr);
	}
	
	for(i=0; i<10; i++){
		var ta = document.createElement('div');
		ta.classList = 'taken';
		
		document.getElementById('tetrisGrid').appendChild(ta);
	}
	
	for(i=0; i<16; i++){
		var mgr = document.createElement('div');
		
		document.getElementById('mini-grid').appendChild(mgr);
	}
	
	start();
}

function start(){
	const grid = document.querySelector('.grid');
	const scoreDisplay = document.getElementById('score');
	const plBtn = document.getElementById('playBtn');
	const reBtn = document.getElementById('resetBtn');
	let squares = Array.from(document.querySelectorAll('.grid > div'));
	
	let isGameOver = false;
	let isPause = true;
	let lvl = 1;
	let blCount = 1;
	
	const width = 10;
	let nextRandom = 0;
	let timerId;
	let score = 0;
	
	const colors = [
		'#F8D104',
		'#F74E0E',
		'#8C47C0',
		'#DF388E',
		'#04C0B0'
	];
	
	const lTe = [
		[1, width+1, width*2+1, 2],
		[width, width+1, width+2, width*2+2],
		[1, width+1, width*2+1, width*2],
		[width, width*2, width*2+1, width*2+2]
	];
	
	const zTe = [
		[0,width,width+1,width*2+1],
		[width+1, width+2,width*2,width*2+1],
		[0,width,width+1,width*2+1],
		[width+1, width+2,width*2,width*2+1]
	];
	
	const tTe = [
		[1,width,width+1,width+2],
		[1,width+1,width+2,width*2+1],
		[width,width+1,width+2,width*2+1],
		[1,width,width+1,width*2+1]
	];
	
	const oTe = [
		[0,1,width,width+1],
		[0,1,width,width+1],
		[0,1,width,width+1],
		[0,1,width,width+1]
	];
	
	const iTe = [
		[1,width+1,width*2+1,width*3+1],
		[width,width+1,width+2,width+3],
		[1,width+1,width*2+1,width*3+1],
		[width,width+1,width+2,width+3]
	];
	
	const allTe = [lTe, zTe, tTe, oTe, iTe];
	
	let currentPosition = 4;
  	let currentRotation = 0;
	
	//randomly select a Tetromino and its first rotation
	let random = Math.floor(Math.random()*allTe.length);
	let current = allTe[random][currentRotation];
	
	function draw() {
		current.forEach(index => {
		  squares[currentPosition + index].classList.add('tetro');
		  if(co)
		  	squares[currentPosition + index].style.backgroundColor = colors[random];
		});
	}
	
	function undraw() {
		current.forEach(index => {
		  squares[currentPosition + index].classList.remove('tetro');
		  squares[currentPosition + index].style.background = '';
		});
	}
	
	function moveDown() {
		if(!isGameOver){
			undraw();
			currentPosition += width;
			draw();
			freeze();
		}
	}
	
	function freeze() {
		if(current.some(index => squares[currentPosition + index + width].classList.contains('taken'))) {
		  	current.forEach(index => squares[currentPosition + index].classList.add('taken'));
			//start a new tetromino falling
			newTeFall();
		}
	}
	
	function newTeFall(){
		getRandomTe();
		currentPosition = 4;
		  
		blCount++;
	 	if(blCount > 15){
			blCount = 1;
			lvl++;
			document.getElementById('level').innerHTML = 'Cấp độ<br>' + lvl;
			setLevel();
		}
		  
		draw();
		displayShape();
		addScore();
		gameOver();
	}
	
	function getRandomTe(){
		random = nextRandom;
		nextRandom = Math.floor(Math.random() * allTe.length);
		current = allTe[random][currentRotation];
	}
	
	
	//----------MOVES------------------
	function moveLeft() {
		undraw();
		const isAtLeftEdge = current.some(index => (currentPosition + index) % width === 0);
		
		if(!isAtLeftEdge) currentPosition -=1;
		if(current.some(index => squares[currentPosition + index].classList.contains('taken'))) {
		  currentPosition +=1;
		}
		draw();
	}
	
	function moveRight() {
		undraw();
		const isAtRightEdge = current.some(index => (currentPosition + index) % width === width -1);
		
		if(!isAtRightEdge) currentPosition +=1;
		if(current.some(index => squares[currentPosition + index].classList.contains('taken'))) {
		  currentPosition -=1
		}
		draw();
	}
	
	//ROTATION
	function isAtRight() {
		return current.some(index=> (currentPosition + index + 1) % width === 0);
	}
	  
	function isAtLeft() {
		return current.some(index=> (currentPosition + index) % width === 0);
	}
	
	function checkRotatedPosition(P){
		P = P || currentPosition;   //get current position.  Then, check if the piece is near the left side.
		if ((P+1) % width < 4) {     //add 1 because the position index can be 1 less than where the piece is (with how they are indexed).     
		  if (isAtRight()){            //use actual position to check if it's flipped over to right side
			currentPosition += 1;   //if so, add one to wrap it back around
			checkRotatedPosition(P); //check again.  Pass position from start, since long block might need to move more.
			}
		}else if (P % width > 5) {
		  if (isAtLeft()){
			currentPosition -= 1;
		  	checkRotatedPosition(P);
		  }
		}
	}
	
	function rotate() {
		if(!isGameOver){
			undraw();
			currentRotation++;
			if(currentRotation === current.length) {
			  currentRotation = 0;
			}
			current = allTe[random][currentRotation];
			checkRotatedPosition();
			draw();
		}
	}
	
	
	//--------UPDATE LEVEL----------------
	function setLevel(){
		var levelTime = 1000 - lvl * 50;
		if(levelTime < 50){
			levelTime = 50;
		}
		//if(timerId) {
			clearInterval(timerId);
			timerId = null;
			timerId = setInterval(moveDown, levelTime);
		//}
	}
	
	
	//----------MINI DISPLAY-----------------
	const displaySquares = document.querySelectorAll('.mini-grid div');
	const displayWidth = 4;
	const displayIndex = 0;
	
	const upNextTetrominoes = [
		[1, displayWidth+1, displayWidth*2+1, 2], //lTetromino
		[0, displayWidth, displayWidth+1, displayWidth*2+1], //zTetromino
		[1, displayWidth, displayWidth+1, displayWidth+2], //tTetromino
		[0, 1, displayWidth, displayWidth+1], //oTetromino
		[1, displayWidth+1, displayWidth*2+1, displayWidth*3+1] //iTetromino
	];
	
	function displayShape() {
		//remove any trace of a tetromino form the entire grid
		displaySquares.forEach(square => {
		  square.classList.remove('tetro');
      	  square.style.backgroundColor = '';
		});
		upNextTetrominoes[nextRandom].forEach( index => {
		  displaySquares[displayIndex + index].classList.add('tetro');
		  if(co)
		  	displaySquares[displayIndex + index].style.backgroundColor = colors[nextRandom];
		});
	}
	
	
	//--------------GAME SCORE/OVER------------
	function addScore() {
		for (let i = 0; i < 199; i +=width) {
		  const row = [i, i+1, i+2, i+3, i+4, i+5, i+6, i+7, i+8, i+9];
	
		  if(row.every(index => squares[index].classList.contains('taken'))) {
			score +=10;
			scoreDisplay.innerHTML = 'Ghi bàn<br>' + score;
			row.forEach(index => {
			  squares[index].classList.remove('taken');
			  squares[index].classList.remove('tetro');
          	  squares[index].style.backgroundColor = '';
			})
			const squaresRemoved = squares.splice(i, width);
			squares = squaresRemoved.concat(squares);
			squares.forEach(cell => grid.appendChild(cell));
		  }
		}
	}
	
	function gameOver() {
		if(current.some(index => squares[currentPosition + index].classList.contains('taken'))) {
			populateGridOver();
			if(score > highScore){
				highScore = score;
				localStorage.setItem('tetro', highScore);
			}
		  	scoreDisplay.innerHTML = 'Ghi bàn<br>' + score;
			document.getElementById('highscore').innerHTML = 'Điểm cao<br>' + highScore;
		  	isGameOver = true;
		  	plBtn.innerHTML = 'Chơi lại';
		  	clearInterval(timerId);
		}
	}
	
	function populateGridOver(){
		for (let i = 0; i < 199; i +=width) {
			const row = [i, i+1, i+2, i+3, i+4, i+5, i+6, i+7, i+8, i+9];
			
			row.forEach(index => {
			  squares[index].classList.add('tetro');
			});
		}
	}
	
	function cleanGrid(){
		for (let i = 0; i < 199; i +=width) {
			const row = [i, i+1, i+2, i+3, i+4, i+5, i+6, i+7, i+8, i+9];
			
			row.forEach(index => {
			  squares[index].classList.remove('taken');
			  squares[index].classList.remove('tetro');
          	  squares[index].style.backgroundColor = '';
			});
		}
	}
	
	
	//-----------START GAME-------------
	plBtn.addEventListener('click', () => {
		if(!isGameOver){
			if(timerId) {
			  clearInterval(timerId);
			  timerId = null;
			  plBtn.innerHTML = 'Chơi';
			  isPause = true;
			} else {
			  startGame();
			}
		}else{
			cleanGrid();
			isGameOver = false;
			score = 0;
			scoreDisplay.innerHTML = 'Ghi bàn<br>' + score;
			startGame();
		}
	});
	
	function startGame(){
		draw();
		//timerId = setInterval(moveDown, 1000);
		setLevel();
		if(!isPause)
			nextRandom = Math.floor(Math.random()*allTe.length);
		displayShape();
		plBtn.innerHTML = 'Tạm dừng';
		isPause = false;
	}
	
	reBtn.addEventListener('click', () => {
		if(!isGameOver){
			cleanGrid();
			clearInterval(timerId);
			timerId = null;
			
			isGameOver = false;
			isPause = false;
			
			score = 0;
			scoreDisplay.innerHTML = 'Ghi bàn<br>' + score;
			
			getRandomTe();
			currentPosition = 4;
			
			plBtn.innerHTML = 'Chơi';
			//startGame();
		}
	});
	
	//--------------BUTTONS-------------------
	document.getElementById('left').addEventListener('mousedown',function(e){//touchstart
		if(!isPause){
			document.getElementById('left').style.opacity = 0.5;
			setTimeout(function(){
				document.getElementById('left').style.opacity = 1;
			},200);
			moveLeft();
			/*timer = setTimeout(function(){
				if(!longPress){
					timer2 = setInterval(function(){
						console.log('left');
						moveLeft();
					}, 75);
					longPress = true;
				}
			},200);*/
			
		}
	},true);
	
	/*document.getElementById('left').addEventListener('mouseup',function(e){
		document.getElementById('left').style.opacity = 1;
		if (timer) clearInterval(timer);
		if(!longPress){
			moveLeft();
		}else{
			if (timer2) clearInterval(timer2);
			longPress = false;
		}
	},true);*/
	
	document.getElementById('down').addEventListener('mousedown',function(e){
		if(!isPause){
			document.getElementById('down').style.opacity = 0.5;
			setTimeout(function(){
				document.getElementById('down').style.opacity = 1;
			},200);
			moveDown();
		}
	},true);
	
	document.getElementById('right').addEventListener('mousedown',function(e){
		if(!isPause)	{
			document.getElementById('right').style.opacity = 0.5;
			setTimeout(function(){
				document.getElementById('right').style.opacity = 1;
			},200);
			moveRight();
		}
	},true);
	
	document.getElementById('rotate').addEventListener('mousedown',function(e){
		if(!isPause)	{
			document.getElementById('rotate').style.opacity = 0.5;
			setTimeout(function(){
				document.getElementById('rotate').style.opacity = 1;
			},200);
			rotate();
		}
	},true);
	
}



/*
function dismiss(){
	clearTimeout(timer2);
	longPress = false;
	document.getElementById('widCont').classList.remove('edit');
}

function checkPhoto(){
	const reader = new FileReader();
	const fileInput = document.getElementById("choose");
	
	reader.onload = (function(theFile) { 
		var image = new Image();
		image.src = theFile.target.result;
		
		image.onload = function() {
			document.getElementById("photoImgBg").src = this.src;
			document.getElementById("photoImg").src = this.src;
		};
		
		localStorage.setItem('photoImgXa', theFile.target.result);
	});
	
	fileInput.addEventListener('change', e => {
		const f = e.target.files[0];
	  	reader.readAsDataURL(f);
	})
}



function openApp(app){
	api.apps.launchApplication(app);
}
*/

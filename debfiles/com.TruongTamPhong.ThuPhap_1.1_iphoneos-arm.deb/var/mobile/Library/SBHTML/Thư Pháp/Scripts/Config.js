// Configuration Language //
var Lang = "vn"
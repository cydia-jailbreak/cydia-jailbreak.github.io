var changeSettings= function() {
document.getElementById("Calendar").style.color = CalendarColor;
document.getElementById("Day").style.color = DayColor;
document.getElementById("Hour").style.color = HourColor;
document.getElementById("Minute").style.color = MinuteColor;
}  
changeSettings();
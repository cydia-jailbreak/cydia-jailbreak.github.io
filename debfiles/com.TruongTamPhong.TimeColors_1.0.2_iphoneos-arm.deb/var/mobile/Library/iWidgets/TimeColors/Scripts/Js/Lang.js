Lang = _lang;
if (Lang == "en") {
var shortdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var shortmonths = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
}

if (Lang == "vi") {
var shortdays = ["Chủ Nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
var shortmonths = ["Tháng giêng", "Tháng hai", "Tháng ba", "Tháng tư", "Tháng năm", "Tháng sáu", "Tháng bảy", "Tháng tám", "Tháng chín", "Tháng mười", "Tháng m.một", "Tháng m.hai"];
}
var twentyfourhour = true;
var pad = false;
var iconSet = "Weather"	     // Do not Modify.




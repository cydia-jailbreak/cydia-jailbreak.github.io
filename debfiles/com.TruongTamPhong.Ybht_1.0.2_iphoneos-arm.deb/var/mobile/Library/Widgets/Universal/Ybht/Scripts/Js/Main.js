var changeSettings= function() {
document.getElementById("Battery").style.color = AllColor;
document.getElementById("Hour").style.color = AllColor;
document.getElementById("City").style.color = AllColor;}
changeSettings();
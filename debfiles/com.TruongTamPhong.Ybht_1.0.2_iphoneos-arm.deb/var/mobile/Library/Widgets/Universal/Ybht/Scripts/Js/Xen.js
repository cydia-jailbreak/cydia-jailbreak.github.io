function mainUpdate(type){ 
if(type === "weather"){checkWeather();
} else if (type === "battery"){updateBattery();}
function checkWeather(){
document.getElementById('City').innerHTML = weather.city;
document.getElementById('Condition').innerHTML = condition[weather.conditionCode] + ' ' + weather.temperature + '&deg;C';
document.getElementById('HiLo').innerHTML = hightext + weather.high + '&deg;' + ' / ' + lowtext + weather.low + '&deg;';}}
init_reload();
function init_reload(){setInterval( function() {
window.location.reload();}, 3600000);}
function updateBattery() {
document.getElementById("Battery").innerHTML = battext + batteryPercent + '%';	
}
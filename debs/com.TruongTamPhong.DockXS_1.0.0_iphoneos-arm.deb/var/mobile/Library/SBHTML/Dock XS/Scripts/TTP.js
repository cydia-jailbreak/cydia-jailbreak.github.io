/* */ var savedElements = {"overlay":"","placedElements":{"boxOne":{"left":"8px","border-color":"rgb(255, 255, 255)","border-width":"1px","position":"absolute","border-radius":"26.8px","width":"299.5px","box-shadow":"rgb(255,255,255) 0px 0px 12px","background":"linear-gradient(150deg,rgba(32,178,170,0),rgba(255,255,255,0) 50%,rgba(32,178,170, 0) 90%)","height":"79.5px","background-color":"rgba(130, 130, 130, 0.38)","z-index":"1","border-style":"solid","top":599,"-webkit-transform":"rotate(0deg)"}},"iconName":"simply"}



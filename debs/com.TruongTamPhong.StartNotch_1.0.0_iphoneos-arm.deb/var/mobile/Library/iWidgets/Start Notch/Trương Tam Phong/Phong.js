/* */ var savedElements = {"overlay":"","placedElements":{
"boxZezo":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"46.2px"},

"boxOne":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"46.2px"},

"boxTwo":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"48px"},

"boxThree":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"48px"},

"boxFor":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"44.5px"},



"boxFive":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"91.2px"},

"boxSix":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"91.2px"},

"boxSeven":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"93px"},

"boxEight":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"93px"},

"boxNine":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"89.5px"},



"boxTen":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"136.2px"},

"boxEleven":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"136.2px"},

"boxTewlve":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"138px"},

"boxThirteen":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"138px"},

"boxForteen":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"134.5px"},



"boxFiveteen":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"181.2px"},

"boxSixteen":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"181.2px"},

"boxSeventeen":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"183px"},

"boxEightteen":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"183px"},

"boxNineteen":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"179.5px"},



"boxTwenty":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"226.2px"},

"boxTwentyOne":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"226.2px"},

"boxTwentyTwo":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"228px"},

"boxTwentyThree":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"228px"},

"boxTwentyFor":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"224.5px"},



"boxTwentyFive":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"271.2px"},

"boxTwentySix":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"271.2px"},

"boxTwentySeven":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"273px"},

"boxTwentyEight":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"273px"},

"boxTwentyNine":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"269.5px"},



"boxThirtyOne":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"316.2px"},

"boxThirtyTwo":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"316.2px"},

"boxThirtyThree":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"318px"},

"boxThirtyFor":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"318px"},

"boxThirtyFive":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"314.5px"},



"boxThirtySix":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"361.2px"},

"boxThirtySeven":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"361.2px"},

"boxThirtyEight":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"363px"},

"boxThirtyNine":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"363px"},

"boxForty":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"359.5px"},



"boxFortyOne":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"406.2px"},

"boxFortyTwo":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"406.2px"},

"boxFortyThree":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"408px"},

"boxFortyFor":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"408px"},

"boxFortyFive":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"404.5px"},



"boxFortySix":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"451.2px"},

"boxFortySeven":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"451.2px"},

"boxFortyEight":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"453px"},

"boxFortyNine":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"453px"},

"boxFifty":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"449.5px"},



"boxFiftyOne":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"496.2px"},

"boxFiftyTwo":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"496.2px"},

"boxFiftyThree":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"498px"},

"boxFiftyFor":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"498px"},

"boxFiftyFive":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"494.5px"},



"boxFiftySix":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"541.2px"},

"boxFiftySeven":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"541.2px"},

"boxFiftyEight":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"543px"},

"boxFiftyNine":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"543px"},

"boxSixty":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"539.5px"},



"boxSixtyOne":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"586.2px"},

"boxSixtyTwo":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"586.2px"},

"boxSixtyThree":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"588px"},

"boxSixtyFor":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"588px"},

"boxSixtyFive":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"584.5px"},



"boxSixtySix":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"631.2px"},

"boxSixtySeven":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"631.2px"},

"boxSixtyEight":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"633px"},

"boxSixtyNine":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"633px"},

"boxSeventy":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"629.5px"},



"boxSeventyOne":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"676.2px"},

"boxSeventyTwo":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"676.2px"},

"boxSeventyThree":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"678px"},

"boxSeventyFor":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"678px"},

"boxSeventyFive":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"674.5px"},




"boxOneHundredSixtyTwo":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"721.2px"},

"boxOneHundredSixtyThree":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"721.2px"},

"boxOneHundredSixtyFor":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"723px"},

"boxOneHundredSixtyFive":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"723px"},

"boxOneHundredSixtySix":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"719.5px"},



"boxOneHundredSixtySeven":{"left":"3px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"766.2px"},

"boxOneHundredSixtyEight":{"left":"-2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"766.2px"},

"boxOneHundredSixtyNine":{"left":"0px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"768px"},

"boxOneHundredSeventy":{"left":"2px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"768px"},

"boxOneHundredSeventyOne":{"left":"0.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"764.5px"},
















"boxSeventySix":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"46.2px"},

"boxSeventySeven":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"46.2px"},

"boxSeventyEight":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"48px"},

"boxSeventyNine":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"48px"},

"boxEightty":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"44.5px"},



"boxEighttyOne":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"91.2px"},

"boxEighttyTwo":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"91.2px"},

"boxEighttyThree":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"93px"},

"boxEighttyFor":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"93px"},

"boxEighttyFive":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"89.5px"},



"boxEighttySix":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"136.2px"},

"boxEighttySeven":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"136.2px"},

"boxEighttyEight":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"138px"},

"boxEighttyNine":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"138px"},

"boxNinety":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"134.5px"},



"boxNinetyOne":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"181.2px"},

"boxNinetyTwo":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"181.2px"},

"boxNinetyThree":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"183px"},

"boxNinetyFor":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"183px"},

"boxNinetyFive":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"179.5px"},



"boxNinetySix":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"226.2px"},

"boxNinetySeven":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"226.2px"},

"boxNinetyEight":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"228px"},

"boxNinetyNine":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"228px"},

"boxonehundred":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"224.5px"},



"boxOneHundredOne":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"271.2px"},

"boxOneHundredTwo":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"271.2px"},

"boxOneHundredThree":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"273px"},

"boxOneHundredFor":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"273px"},

"boxOneHundredFive":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"269.5px"},



"boxOneHundredSix":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"316.2px"},

"boxOneHundredSeven":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"316.2px"},

"boxOneHundredEight":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"318px"},

"boxOneHundredNine":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"318px"},

"boxOneHundredEleven":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"314.5px"},



"boxOneHundredTwelve":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"361.2px"},

"boxOneHundredThirteen":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"361.2px"},

"boxOneHundredForteen":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"363px"},

"boxOneHundredFifteen":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"363px"},

"boxOneHundredSixteen":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"359.5px"},



"boxOneHundredSeventeen":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"406.2px"},

"boxOneHundredEightteen":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"406.2px"},

"boxOneHundredNineteen":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"408px"},

"boxOneHundredTwenty":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"408px"},

"boxOneHundredTwentyOne":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"404.5px"},



"boxOneHundredTwentyTwo":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"451.2px"},

"boxOneHundredTwentyThree":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"451.2px"},

"boxOneHundredTwentyFor":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"453px"},

"boxOneHundredTwentyFive":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"453px"},

"boxOneHundredTwentySix":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"449.5px"},



"boxOneHundredTwentySeven":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"496.2px"},

"boxOneHundredTwentyEight":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"496.2px"},

"boxOneHundredTwentyNine":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"498px"},

"boxOneHundredThirty":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"498px"},

"boxOneHundredThirtyOne":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"494.5px"},



"boxOneHundredThirtyTwo":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"541.2px"},

"boxOneHundredThirtyThree":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"541.2px"},

"boxOneHundredThirtyFor":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"543px"},

"boxOneHundredThirtyFive":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"543px"},

"boxOneHundredThirtySix":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"539.5px"},



"boxOneHundredThirtySeven":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"586.2px"},

"boxOneHundredThirtyEight":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"586.2px"},

"boxOneHundredThirtyNine":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"588px"},

"boxOneHundredForty":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"588px"},

"boxOneHundredFortyOne":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"584.5px"},



"boxOneHundredFortyTwo":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"631.2px"},

"boxOneHundredFortyThree":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"631.2px"},

"boxOneHundredFortyFor":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"633px"},

"boxOneHundredFortyFive":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"633px"},

"boxOneHundredFortySix":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"629.5px"},



"boxOneHundredFortySeven":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"676.2px"},

"boxOneHundredFortyEight":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"676.2px"},

"boxOneHundredFortyNine":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"678px"},

"boxOneHundredFifty":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"678px"},

"boxOneHundredFiftyOne":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"674.5px"},




"boxOneHundredFiftyTwo":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"721.2px"},

"boxOneHundredFiftyThree":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"721.2px"},

"boxOneHundredFiftyFor":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"723px"},

"boxOneHundredFiftyFive":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"723px"},

"boxOneHundredFiftySix":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"719.5px"},



"boxOneHundredFiftySeven":{"left":"361px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"766.2px"},

"boxOneHundredFiftyEight":{"left":"356px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"766.2px"},

"boxOneHundredFiftyNine":{"left":"358px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"768px"},

"boxOneHundredSixty":{"left":"360px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"768px"},

"boxOneHundredSixtyOne":{"left":"358.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"764.5px"},













"boxOneHundredSeventyTwo":{"left":"46px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredSeventyThree":{"left":"41px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredSeventyFor":{"left":"43px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredSeventyFive":{"left":"45px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredSeventySix":{"left":"43.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"798.5px"},



"boxOneHundredSeventySeven":{"left":"91px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredSeventyEight":{"left":"86px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredSeventyNine":{"left":"88px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredEightty":{"left":"90px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredEighttyOne":{"left":"88.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"798.5px"},



"boxOneHundredEighttyTwo":{"left":"136px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredEighttyThree":{"left":"131px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredEighttyFor":{"left":"133px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredEighttyFive":{"left":"135px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredEighttySix":{"left":"133.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"798.5px"},



"boxOneHundredEighttySeven":{"left":"181px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredEighttyEight":{"left":"176px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredEighttyNine":{"left":"178px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredNinety":{"left":"180px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredNinetyOne":{"left":"178.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"798.5px"},



"boxOneHundredNinetyTwo":{"left":"226px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredNinetyThree":{"left":"221px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredNinetyFor":{"left":"223px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredNinetyFive":{"left":"225px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxOneHundredNinetySix":{"left":"223.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"798.5px"},



"boxOneHundredNinetySeven":{"left":"271px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredNinetyEight":{"left":"266px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxOneHundredNinetyNine":{"left":"268px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxTwoHundred":{"left":"270px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxTwoHundredOne":{"left":"268.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"798.5px"},



"boxTwoHundredTwo":{"left":"316px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxTwoHundredThree":{"left":"311px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-69.5deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"800.2px"},

"boxTwoHundredFor":{"left":"313px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxTwoHundredFive":{"left":"315px","border-color":"#E8E8E8","border-width":"1px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(-215deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"802px"},

"boxTwoHundredSix":{"left":"313.5px","border-color":"#E8E8E8","border-width":"0.8px","position":"absolute","border-radius":"0px","width":"12px","-webkit-transform":"rotate(0deg)","box-shadow":"#E8E8E8 0px 0px 5px","height":"0px","z-index":"0","border-style":"solid","top":"798.5px"}
} ,"iconName":"StartNotch"}



function swipe() {
    var text = new Array;

    text.push("Touch to unlock </br>"); 
    text.push("↑ </br>");
var text = (text[(Math.floor (Math.random() * text.length))]);
        
    return text;
   
}